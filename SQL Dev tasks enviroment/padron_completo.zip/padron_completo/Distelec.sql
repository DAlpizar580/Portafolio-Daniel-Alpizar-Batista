101001,SAN JOSE,CENTRAL,HOSPITAL                                                
101002,SAN JOSE,CENTRAL,ZAPOTE                                                  
101003,SAN JOSE,CENTRAL,SAN FRANCISCO DE DOS RIOS                               
101004,SAN JOSE,CENTRAL,URUCA                                                   
101005,SAN JOSE,CENTRAL,MATA REDONDA                                            
101006,SAN JOSE,CENTRAL,PAVAS                                                   
101007,SAN JOSE,CENTRAL,HATILLO                                                 
101008,SAN JOSE,CENTRAL,SAN SEBASTIAN                                           
101009,SAN JOSE,CENTRAL,LA CAJA                                                 
101010,SAN JOSE,CENTRAL,PASO ANCHO SUR                                          
101011,SAN JOSE,CENTRAL,CARMEN                                                  
101012,SAN JOSE,CENTRAL,BARRIO MEXICO                                           
101013,SAN JOSE,CENTRAL,CATEDRAL                                                
101014,SAN JOSE,CENTRAL,CORAZON DE JESUS                                        
101015,SAN JOSE,CENTRAL,ARANJUEZ                                                
101016,SAN JOSE,CENTRAL,PITAHAYA                                                
101017,SAN JOSE,CENTRAL,CRISTO REY                                              
101018,SAN JOSE,CENTRAL,OMAR DENGO                                              
101020,SAN JOSE,CENTRAL,SAN BOSCO                                               
101021,SAN JOSE,CENTRAL,GONZALEZ VIQUEZ                                         
101022,SAN JOSE,CENTRAL,NACIONES UNIDAS                                         
101023,SAN JOSE,CENTRAL,BARRIO LUJAN                                            
101024,SAN JOSE,CENTRAL,PASO ANCHO NORTE                                        
101025,SAN JOSE,CENTRAL,SAGRADA FAMILIA                                         
101026,SAN JOSE,CENTRAL,RINCON GRANDE                                           
101027,SAN JOSE,CENTRAL,MARIA REINA                                             
101028,SAN JOSE,CENTRAL,VILLA ESPERANZA                                         
101029,SAN JOSE,CENTRAL,ROSITER CARBALLO (LAS BRISAS)                           
101030,SAN JOSE,CENTRAL,CAI. SAN JOSE                                           
101031,SAN JOSE,CENTRAL,LA CARPIO                                               
101032,SAN JOSE,CENTRAL,CORDOBA                                                 
101033,SAN JOSE,CENTRAL,SANTA MARTA                                             
101034,SAN JOSE,CENTRAL,LA PEREGRINA                                            
101035,SAN JOSE,CENTRAL,PERPETUO SOCORRO                                        
101036,SAN JOSE,CENTRAL,HATILLO 8                                               
101037,SAN JOSE,CENTRAL,COLONIA 15 DE SETIEMBRE                                 
101038,SAN JOSE,CENTRAL,COLONIA KENNEDY                                         
101040,SAN JOSE,CENTRAL,C.S.M CAPEMCOL                                          
102001,SAN JOSE,ESCAZU,ESCAZU                                                   
102002,SAN JOSE,ESCAZU,SAN ANTONIO                                              
102003,SAN JOSE,ESCAZU,SAN RAFAEL                                               
102004,SAN JOSE,ESCAZU,BEBEDERO O SAN FRANCISCO                                 
102005,SAN JOSE,ESCAZU,GUACHIPELIN (SAN GABRIEL)                                
102006,SAN JOSE,ESCAZU,CARMEN (CHIVERRAL)                                       
102007,SAN JOSE,ESCAZU,BELO HORIZONTE NORTE                                     
102008,SAN JOSE,ESCAZU,HLE. MAGDALA                                             
103001,SAN JOSE,DESAMPARADOS,DESAMPARADOS                                       
103002,SAN JOSE,DESAMPARADOS,SAN MIGUEL                                         
103003,SAN JOSE,DESAMPARADOS,JERICO                                             
103004,SAN JOSE,DESAMPARADOS,HIGUITO                                            
103005,SAN JOSE,DESAMPARADOS,SAN JUAN DE DIOS                                   
103006,SAN JOSE,DESAMPARADOS,SAN RAFAEL ARRIBA                                  
103007,SAN JOSE,DESAMPARADOS,SAN RAFAEL ABAJO                                   
103008,SAN JOSE,DESAMPARADOS,SAN ANTONIO                                        
103009,SAN JOSE,DESAMPARADOS,FRAILES                                            
103010,SAN JOSE,DESAMPARADOS,BUSTAMANTE O ALCIRA                                
103011,SAN JOSE,DESAMPARADOS,PATARRA                                            
103012,SAN JOSE,DESAMPARADOS,SAN CRISTOBAL SUR                                  
103013,SAN JOSE,DESAMPARADOS,SAN CRISTOBAL NORTE                                
103014,SAN JOSE,DESAMPARADOS,ROSARIO                                            
103015,SAN JOSE,DESAMPARADOS,GUADARRAMA                                         
103016,SAN JOSE,DESAMPARADOS,LA JOYA                                            
103017,SAN JOSE,DESAMPARADOS,FATIMA DE DAMAS                                    
103018,SAN JOSE,DESAMPARADOS,CALLE FALLAS                                       
103019,SAN JOSE,DESAMPARADOS,GRAVILIAS                                          
103020,SAN JOSE,DESAMPARADOS,PACAYA                                             
103021,SAN JOSE,DESAMPARADOS,EL LLANO                                           
103022,SAN JOSE,DESAMPARADOS,MANZANO (MANZANILLO)                               
103023,SAN JOSE,DESAMPARADOS,GUATUSO                                            
103024,SAN JOSE,DESAMPARADOS,TRINIDAD (PARTE ESTE)                              
103025,SAN JOSE,DESAMPARADOS,CRISTO REY                                         
103026,SAN JOSE,DESAMPARADOS,LOS GUIDO                                          
103027,SAN JOSE,DESAMPARADOS,LAS LOMAS                                          
103028,SAN JOSE,DESAMPARADOS,SAN JERONIMO                                       
103029,SAN JOSE,DESAMPARADOS,VIOLETA (RINCON MORALES)                           
103030,SAN JOSE,DESAMPARADOS,SAN LORENZO                                        
103031,SAN JOSE,DESAMPARADOS,VALENCIA                                           
103032,SAN JOSE,DESAMPARADOS,EL PORVENIR                                        
103033,SAN JOSE,DESAMPARADOS,LA CAPRI                                           
103034,SAN JOSE,DESAMPARADOS,CAI. VILMA CURLING RIVERA                          
103035,SAN JOSE,DESAMPARADOS,EMPALME ARRIBA GUARIA(PARTE OESTE)                 
103036,SAN JOSE,DESAMPARADOS,HLE. OFELIA CARVAJAL DE NARANJO                    
103037,SAN JOSE,DESAMPARADOS,HLE. SAN CAYETANO                                  
103038,SAN JOSE,DESAMPARADOS,LLANO BONITO                                       
103039,SAN JOSE,DESAMPARADOS,CHIROGRES                                          
104001,SAN JOSE,PURISCAL,SANTIAGO                                               
104002,SAN JOSE,PURISCAL,POZOS                                                  
104003,SAN JOSE,PURISCAL,MERCEDES SUR                                           
104004,SAN JOSE,PURISCAL,MERCEDES NORTE                                         
104005,SAN JOSE,PURISCAL,BOCANA                                                 
104006,SAN JOSE,PURISCAL,JILGUERAL                                              
104008,SAN JOSE,PURISCAL,TUFARES                                                
104009,SAN JOSE,PURISCAL,SALITRALES                                             
104011,SAN JOSE,PURISCAL,ALTO LA PALMA                                          
104012,SAN JOSE,PURISCAL,BARBACOAS (SAN ISIDRO)                                 
104013,SAN JOSE,PURISCAL,PIEDADES                                               
104014,SAN JOSE,PURISCAL,SAN JUAN                                               
104015,SAN JOSE,PURISCAL,GRIFO ALTO                                             
104016,SAN JOSE,PURISCAL,LLANO GRANDE                                           
104017,SAN JOSE,PURISCAL,GRIFO BAJO                                             
104018,SAN JOSE,PURISCAL,SAN RAFAEL ARRIBA                                      
104019,SAN JOSE,PURISCAL,FLORALIA                                               
104020,SAN JOSE,PURISCAL,CANDELARITA                                            
104021,SAN JOSE,PURISCAL,DESAMPARADITOS                                         
104022,SAN JOSE,PURISCAL,SAN ANTONIO ARRIBA                                     
104023,SAN JOSE,PURISCAL,GUARUMAL                                               
104024,SAN JOSE,PURISCAL,ZAPATON (SAN CARLOS)                                   
104026,SAN JOSE,PURISCAL,PEDERNAL O SAN PEDRO                                   
104028,SAN JOSE,PURISCAL,GAMALOTILLO                                            
104029,SAN JOSE,PURISCAL,LOS ANGELES                                            
104030,SAN JOSE,PURISCAL,LA GLORIA                                              
104031,SAN JOSE,PURISCAL,MASTATAL                                               
104032,SAN JOSE,PURISCAL,SANTA MARTA                                            
104034,SAN JOSE,PURISCAL,CARIT                                                  
104035,SAN JOSE,PURISCAL,CORTEZAL                                               
104036,SAN JOSE,PURISCAL,CERBATANA                                              
104037,SAN JOSE,PURISCAL,SAN MARTIN                                             
104038,SAN JOSE,PURISCAL,CHARCON (RIO VIEJO)                                    
104040,SAN JOSE,PURISCAL,SAN MIGUEL                                             
104042,SAN JOSE,PURISCAL,BAJO BADILLA                                           
104043,SAN JOSE,PURISCAL,VISTA DE MAR NORTE                                     
104044,SAN JOSE,PURISCAL,BAJO REY                                               
104045,SAN JOSE,PURISCAL,HLE. CORAZON DE JESUS                                  
104046,SAN JOSE,PURISCAL,SANTA CECILIA                                          
105001,SAN JOSE,TARRAZU,SAN MARCOS                                              
105002,SAN JOSE,TARRAZU,SAN PEDRO                                               
105004,SAN JOSE,TARRAZU,SAN MARTIN                                              
105005,SAN JOSE,TARRAZU,SAN LORENZO                                             
105006,SAN JOSE,TARRAZU,GUADALUPE                                               
105007,SAN JOSE,TARRAZU,RODEO NORTE                                             
105008,SAN JOSE,TARRAZU,SAN CARLOS                                              
105009,SAN JOSE,TARRAZU,ESQUIPULAS                                              
105010,SAN JOSE,TARRAZU,SAN JERONIMO                                            
105012,SAN JOSE,TARRAZU,SAN MIGUEL O SALADO                                     
105013,SAN JOSE,TARRAZU,ZAPOTAL                                                 
105014,SAN JOSE,TARRAZU,NAPOLES                                                 
105015,SAN JOSE,TARRAZU,QUEBRADA ARROYO                                         
105016,SAN JOSE,TARRAZU,HLE. LOS SANTOS                                         
106001,SAN JOSE,ASERRI,ASERRI                                                   
106002,SAN JOSE,ASERRI,POAS                                                     
106003,SAN JOSE,ASERRI,SALITRILLOS                                              
106004,SAN JOSE,ASERRI,JOCOTAL ABAJO                                            
106005,SAN JOSE,ASERRI,TARBACA O PRAGA                                          
106006,SAN JOSE,ASERRI,VUELTA DE JORCO                                          
106007,SAN JOSE,ASERRI,MONTE REDONDO                                            
106008,SAN JOSE,ASERRI,SAN GABRIEL                                              
106009,SAN JOSE,ASERRI,LIMONAL                                                  
106010,SAN JOSE,ASERRI,LA LEGUA                                                 
106011,SAN JOSE,ASERRI,BAJO DE PARRITA                                          
106012,SAN JOSE,ASERRI,MONTERREY                                                
106013,SAN JOSE,ASERRI,LEGUA DE LOS NARANJOS                                    
106014,SAN JOSE,ASERRI,URUCA                                                    
106015,SAN JOSE,ASERRI,EL TIGRE                                                 
106016,SAN JOSE,ASERRI,CEDRAL                                                   
106017,SAN JOSE,ASERRI,TRANQUERILLAS                                            
106018,SAN JOSE,ASERRI,ALTO AGUACATE                                            
106020,SAN JOSE,ASERRI,LAGUNA (BAJO BIJAGUAL)                                   
106022,SAN JOSE,ASERRI,OJO DE AGUA (PARTE NOROESTE)                             
106023,SAN JOSE,ASERRI,SANTA TERESITA                                           
106024,SAN JOSE,ASERRI,HLE. SAN FRANCISCO DE ASIS                               
107001,SAN JOSE,MORA,COLON                                                      
107002,SAN JOSE,MORA,JARIS                                                      
107003,SAN JOSE,MORA,GUAYABO                                                    
107004,SAN JOSE,MORA,TABARCIA                                                   
107005,SAN JOSE,MORA,PIEDRAS BLANCAS                                            
107006,SAN JOSE,MORA,MORADO                                                     
107007,SAN JOSE,MORA,PIEDRAS NEGRAS                                             
107010,SAN JOSE,MORA,PICAGRES                                                   
107011,SAN JOSE,MORA,LLANO GRANDE                                               
107013,SAN JOSE,MORA,CORRALAR                                                   
107014,SAN JOSE,MORA,QUITIRRISI                                                 
107015,SAN JOSE,MORA,BAJO DE LOAIZA (SAN LORENZO)                               
107017,SAN JOSE,MORA,RODEO                                                      
107018,SAN JOSE,MORA,BRASIL                                                     
107019,SAN JOSE,MORA,SAN BOSCO                                                  
107020,SAN JOSE,MORA,SAN RAFAEL (CEDRAL)                                        
107021,SAN JOSE,MORA,CORROGRES (LA FILA EL CARMEN)                              
107022,SAN JOSE,MORA,BAJO DE BUSTAMANTE O ANGELES                               
107023,SAN JOSE,MORA,SAN ISIDRO DE CHUCAS (BALSILLA)                            
107024,SAN JOSE,MORA,BAJO DE JORCO (PARTE OESTE)                                
108001,SAN JOSE,GOICOECHEA,GUADALUPE                                            
108002,SAN JOSE,GOICOECHEA,HLE. CARLOS MARIA ULLOA                              
108003,SAN JOSE,GOICOECHEA,SAN FRANCISCO                                        
108004,SAN JOSE,GOICOECHEA,CALLE BLANCOS Y SAN GABRIEL                          
108005,SAN JOSE,GOICOECHEA,MATA DE PLATANO O CARMEN                             
108006,SAN JOSE,GOICOECHEA,IPIS ABAJO                                           
108007,SAN JOSE,GOICOECHEA,PURRAL                                               
108008,SAN JOSE,GOICOECHEA,RANCHO REDONDO                                       
108009,SAN JOSE,GOICOECHEA,VISTA DE MAR                                         
108010,SAN JOSE,GOICOECHEA,LOS ANGELES                                          
108011,SAN JOSE,GOICOECHEA,FACIO Y LA MORA                                      
108012,SAN JOSE,GOICOECHEA,CUADROS                                              
108013,SAN JOSE,GOICOECHEA,HLE. CORTEZA AMARILLA-EMMANUEL                       
109001,SAN JOSE,SANTA ANA,SANTA ANA                                             
109002,SAN JOSE,SANTA ANA,SALITRAL                                              
109004,SAN JOSE,SANTA ANA,POZOS                                                 
109005,SAN JOSE,SANTA ANA,MATINILLA                                             
109006,SAN JOSE,SANTA ANA,RIO ORO                                               
109007,SAN JOSE,SANTA ANA,PIEDADES                                              
109008,SAN JOSE,SANTA ANA,BRASIL                                                
109009,SAN JOSE,SANTA ANA,LA MINA                                               
109010,SAN JOSE,SANTA ANA,SAN RAFAEL                                            
109011,SAN JOSE,SANTA ANA,HONDURAS                                              
109012,SAN JOSE,SANTA ANA,LAGOS DE LINDORA                                      
110001,SAN JOSE,ALAJUELITA,ALAJUELITA                                           
110002,SAN JOSE,ALAJUELITA,SAN JOSECITO                                         
110003,SAN JOSE,ALAJUELITA,SAN ANTONIO O EL LLANO                               
110004,SAN JOSE,ALAJUELITA,CONCEPCION ABAJO                                     
110005,SAN JOSE,ALAJUELITA,SAN FELIPE                                           
110006,SAN JOSE,ALAJUELITA,LAMPARAS O CORAZON DE JESUS                          
110007,SAN JOSE,ALAJUELITA,AURORA                                               
110008,SAN JOSE,ALAJUELITA,CONCEPCION ARRIBA                                    
110009,SAN JOSE,ALAJUELITA,TEJARCILLOS (JUAN RAFAEL MORA)                       
110010,SAN JOSE,ALAJUELITA,HLE. MANANTIAL DE VIDA                               
111001,SAN JOSE,VAZQUEZ DE CORONADO,SAN ISIDRO                                  
111002,SAN JOSE,VAZQUEZ DE CORONADO,SAN RAFAEL                                  
111003,SAN JOSE,VAZQUEZ DE CORONADO,SAN PEDRO                                   
111004,SAN JOSE,VAZQUEZ DE CORONADO,JESUS O DULCE NOMBRE                        
111005,SAN JOSE,VAZQUEZ DE CORONADO,SAN ANTONIO                                 
111006,SAN JOSE,VAZQUEZ DE CORONADO,LAS NUBES                                   
111007,SAN JOSE,VAZQUEZ DE CORONADO,CASCAJAL                                    
111008,SAN JOSE,VAZQUEZ DE CORONADO,CORAZON DE JESUS                            
112001,SAN JOSE,ACOSTA,SAN IGNACIO                                              
112002,SAN JOSE,ACOSTA,TABLAZO                                                  
112003,SAN JOSE,ACOSTA,CHIRRACA (PARTE ESTE)                                    
112004,SAN JOSE,ACOSTA,AGUA BLANCA (PARTE NORTE)                                
112005,SAN JOSE,ACOSTA,GUAITIL                                                  
112006,SAN JOSE,ACOSTA,TOLEDO                                                   
112007,SAN JOSE,ACOSTA,PALMICHAL                                                
112008,SAN JOSE,ACOSTA,CANGREJAL                                                
112009,SAN JOSE,ACOSTA,CEIBA ESTE                                               
112010,SAN JOSE,ACOSTA,COYOLAR                                                  
112011,SAN JOSE,ACOSTA,SABANILLAS                                               
112012,SAN JOSE,ACOSTA,TERUEL                                                   
112013,SAN JOSE,ACOSTA,BIJAGUAL                                                 
112014,SAN JOSE,ACOSTA,LA CRUZ                                                  
112015,SAN JOSE,ACOSTA,OCOCA                                                    
112016,SAN JOSE,ACOSTA,SEVILLA (CACAO)                                          
112017,SAN JOSE,ACOSTA,BAJO DE JORCO (PARTE ESTE)                               
112019,SAN JOSE,ACOSTA,LLANO DE LA MESA                                         
112020,SAN JOSE,ACOSTA,ZONCUANO                                                 
112021,SAN JOSE,ACOSTA,LAS LIMAS                                                
112022,SAN JOSE,ACOSTA,CASPIROLA                                                
112023,SAN JOSE,ACOSTA,SAN LUIS                                                 
112024,SAN JOSE,ACOSTA,ESCUADRA                                                 
112026,SAN JOSE,ACOSTA,BAJO CACAO O CERDAS                                      
112028,SAN JOSE,ACOSTA,URUCA                                                    
112029,SAN JOSE,ACOSTA,VEGAS DEL PARRITA                                        
112030,SAN JOSE,ACOSTA,LINDA VISTA                                              
112031,SAN JOSE,ACOSTA,HLE. ACOSTA                                              
113001,SAN JOSE,TIBAS,SAN JUAN                                                  
113002,SAN JOSE,TIBAS,ANSELMO LLORENTE                                          
113003,SAN JOSE,TIBAS,COLIMA                                                    
113004,SAN JOSE,TIBAS,CINCO ESQUINAS                                            
113005,SAN JOSE,TIBAS,LEON XIII                                                 
113006,SAN JOSE,TIBAS,CUATRO REINAS                                             
113007,SAN JOSE,TIBAS,FLORIDA (INVU)                                            
114001,SAN JOSE,MORAVIA,SAN VICENTE                                             
114002,SAN JOSE,MORAVIA,SAN JERONIMO                                            
114003,SAN JOSE,MORAVIA,LA TRINIDAD (GUAYABAL)                                  
114004,SAN JOSE,MORAVIA,PLATANARES                                              
114005,SAN JOSE,MORAVIA,LOS SITIOS                                              
114006,SAN JOSE,MORAVIA,HLE. CASA NAZARETH                                      
114007,SAN JOSE,MORAVIA,LA ISLA                                                 
115001,SAN JOSE,MONTES DE OCA,SAN PEDRO                                         
115002,SAN JOSE,MONTES DE OCA,LOURDES                                           
115003,SAN JOSE,MONTES DE OCA,SABANILLA                                         
115004,SAN JOSE,MONTES DE OCA,BETANIA                                           
115005,SAN JOSE,MONTES DE OCA,SAN RAFAEL                                        
115006,SAN JOSE,MONTES DE OCA,CEDROS                                            
115007,SAN JOSE,MONTES DE OCA,HLE. MONTES DE OCA                                
116001,SAN JOSE,TURRUBARES,SAN PABLO                                            
116002,SAN JOSE,TURRUBARES,SAN PEDRO                                            
116003,SAN JOSE,TURRUBARES,SAN JUAN DE MATA                                     
116005,SAN JOSE,TURRUBARES,MONTELIMAR                                           
116006,SAN JOSE,TURRUBARES,LAS DELICIAS                                         
116007,SAN JOSE,TURRUBARES,SAN GABRIEL                                          
116008,SAN JOSE,TURRUBARES,SAN LUIS                                             
116009,SAN JOSE,TURRUBARES,BIJAGUAL                                             
116012,SAN JOSE,TURRUBARES,SAN RAFAEL                                           
116014,SAN JOSE,TURRUBARES,SAN ANTONIO DE TULIN                                 
116016,SAN JOSE,TURRUBARES,SAN FRANCISCO                                        
116017,SAN JOSE,TURRUBARES,EL SUR                                               
116018,SAN JOSE,TURRUBARES,POTENCIANA ARRIBA                                    
116019,SAN JOSE,TURRUBARES,EL BARRO                                             
117001,SAN JOSE,DOTA,SANTA MARIA                                                
117002,SAN JOSE,DOTA,JARDIN                                                     
117003,SAN JOSE,DOTA,COPEY                                                      
117004,SAN JOSE,DOTA,PROVIDENCIA                                                
117005,SAN JOSE,DOTA,LA CIMA                                                    
117006,SAN JOSE,DOTA,TRINIDAD                                                   
117007,SAN JOSE,DOTA,SUKIA O EL BRUJO                                           
117008,SAN JOSE,DOTA,SAN GERARDO                                                
117009,SAN JOSE,DOTA,HLE. SANTA MARIA                                           
118001,SAN JOSE,CURRIDABAT,CURRIDABAT                                           
118003,SAN JOSE,CURRIDABAT,SANCHEZ                                              
118004,SAN JOSE,CURRIDABAT,TIRRASES                                             
118005,SAN JOSE,CURRIDABAT,LA LIA O INMACULADA                                  
118006,SAN JOSE,CURRIDABAT,CIPRESES                                             
118007,SAN JOSE,CURRIDABAT,GRANADILLA                                           
118008,SAN JOSE,CURRIDABAT,JOSE MARIA ZELEDON                                   
118009,SAN JOSE,CURRIDABAT,CIUDADELA QUINCE DE AGOSTO                           
118010,SAN JOSE,CURRIDABAT,HLE. CURRIDABAT                                      
119001,SAN JOSE,PEREZ ZELEDON,SAN ISIDRO DE EL GENERAL                          
119002,SAN JOSE,PEREZ ZELEDON,LA PALMA                                          
119003,SAN JOSE,PEREZ ZELEDON,SANTA ROSA                                        
119004,SAN JOSE,PEREZ ZELEDON,LA ESPERANZA                                      
119005,SAN JOSE,PEREZ ZELEDON,GENERAL VIEJO                                     
119006,SAN JOSE,PEREZ ZELEDON,PALMARES                                          
119007,SAN JOSE,PEREZ ZELEDON,RIVAS                                             
119008,SAN JOSE,PEREZ ZELEDON,SAN PEDRO                                         
119009,SAN JOSE,PEREZ ZELEDON,CANDELARIA O ANGOSTURA                            
119010,SAN JOSE,PEREZ ZELEDON,PEDREGOSO                                         
119011,SAN JOSE,PEREZ ZELEDON,SAN RAMON SUR                                     
119012,SAN JOSE,PEREZ ZELEDON,PACUARITO                                         
119013,SAN JOSE,PEREZ ZELEDON,QUEBRADAS                                         
119014,SAN JOSE,PEREZ ZELEDON,SAN CRISTOBAL O TINAMASTE                         
119015,SAN JOSE,PEREZ ZELEDON,SAN JUAN DE DIOS O GUABO                          
119016,SAN JOSE,PEREZ ZELEDON,LA HERMOSA                                        
119017,SAN JOSE,PEREZ ZELEDON,BOLIVIA                                           
119018,SAN JOSE,PEREZ ZELEDON,SAN JUAN BOSCO (PATIO DE AGUA)                    
119019,SAN JOSE,PEREZ ZELEDON,LA REPUNTA                                        
119020,SAN JOSE,PEREZ ZELEDON,BUENA VISTA                                       
119021,SAN JOSE,PEREZ ZELEDON,PUEBLO NUEVO                                      
119022,SAN JOSE,PEREZ ZELEDON,CANAAN                                            
119023,SAN JOSE,PEREZ ZELEDON,SAN RAFAEL NORTE DE SAN ISIDRO                    
119024,SAN JOSE,PEREZ ZELEDON,LOS REYES                                         
119025,SAN JOSE,PEREZ ZELEDON,SAN RAFAEL DE PLATANARES                          
119026,SAN JOSE,PEREZ ZELEDON,CARMEN O CAJON                                    
119027,SAN JOSE,PEREZ ZELEDON,PLATANILLO                                        
119028,SAN JOSE,PEREZ ZELEDON,QUIZARRA (PARTE ESTE)                             
119029,SAN JOSE,PEREZ ZELEDON,SAN GABRIEL                                       
119030,SAN JOSE,PEREZ ZELEDON,SANTA TERESA                                      
119031,SAN JOSE,PEREZ ZELEDON,PEJIBAYE                                          
119032,SAN JOSE,PEREZ ZELEDON,SANTO TOMAS                                       
119033,SAN JOSE,PEREZ ZELEDON,PE�AS BLANCAS                                     
119034,SAN JOSE,PEREZ ZELEDON,AGUILA ABAJO                                      
119035,SAN JOSE,PEREZ ZELEDON,SAN PABLO                                         
119036,SAN JOSE,PEREZ ZELEDON,ZAPOTE                                            
119037,SAN JOSE,PEREZ ZELEDON,DIVISION (PARTE OESTE)                            
119038,SAN JOSE,PEREZ ZELEDON,DESAMPARADOS                                      
119039,SAN JOSE,PEREZ ZELEDON,SAN MIGUEL                                        
119040,SAN JOSE,PEREZ ZELEDON,MESAS                                             
119041,SAN JOSE,PEREZ ZELEDON,SAVEGRE ABAJO                                     
119042,SAN JOSE,PEREZ ZELEDON,SANTA ELENA                                       
119043,SAN JOSE,PEREZ ZELEDON,SAN RAFAEL DE SAN PEDRO                           
119044,SAN JOSE,PEREZ ZELEDON,BRUJO                                             
119045,SAN JOSE,PEREZ ZELEDON,EL LLANO                                          
119046,SAN JOSE,PEREZ ZELEDON,VILLA BONITA                                      
119047,SAN JOSE,PEREZ ZELEDON,SANTA LUCIA (SANTA LUISA)                         
119048,SAN JOSE,PEREZ ZELEDON,SAN SALVADOR                                      
119049,SAN JOSE,PEREZ ZELEDON,SAN BLAS (LINDA ARRIBA)                           
119050,SAN JOSE,PEREZ ZELEDON,AGUAS BUENAS                                      
119051,SAN JOSE,PEREZ ZELEDON,SAN AGUSTIN                                       
119052,SAN JOSE,PEREZ ZELEDON,HERRADURA                                         
119053,SAN JOSE,PEREZ ZELEDON,TAMBOR                                            
119054,SAN JOSE,PEREZ ZELEDON,SAN JERONIMO                                      
119055,SAN JOSE,PEREZ ZELEDON,FATIMA                                            
119056,SAN JOSE,PEREZ ZELEDON,CONCEPCION (PARTE ESTE)                           
119057,SAN JOSE,PEREZ ZELEDON,SIERRA                                            
119058,SAN JOSE,PEREZ ZELEDON,SAN CARLOS                                        
119059,SAN JOSE,PEREZ ZELEDON,MERCEDES                                          
119060,SAN JOSE,PEREZ ZELEDON,SAN FRANCISCO                                     
119061,SAN JOSE,PEREZ ZELEDON,LA LINDA                                          
119062,SAN JOSE,PEREZ ZELEDON,LA UNION DE SAN PEDRO                             
119063,SAN JOSE,PEREZ ZELEDON,VISTA DE MAR NORTE                                
119064,SAN JOSE,PEREZ ZELEDON,CALLE MORAS                                       
119065,SAN JOSE,PEREZ ZELEDON,LOS ANGELES DE PARAMO                             
119066,SAN JOSE,PEREZ ZELEDON,SAN CAYETANO (RIO NUEVO)                          
119067,SAN JOSE,PEREZ ZELEDON,SAN JUAN DE MIRAMAR (ALTO SN JUAN)                
119068,SAN JOSE,PEREZ ZELEDON,CEIBO ARRIBA                                      
119069,SAN JOSE,PEREZ ZELEDON,CHINA KICHA                                       
119070,SAN JOSE,PEREZ ZELEDON,SAN ANTONIO                                       
119071,SAN JOSE,PEREZ ZELEDON,SIBERIA (PARTE OESTE)                             
119072,SAN JOSE,PEREZ ZELEDON,LA ESE                                            
119073,SAN JOSE,PEREZ ZELEDON,LAS JUNTAS DE PACUAR                              
119074,SAN JOSE,PEREZ ZELEDON,VILLA LIGIA                                       
119075,SAN JOSE,PEREZ ZELEDON,LOS CHILES                                        
119076,SAN JOSE,PEREZ ZELEDON,CHIMIROL                                          
119077,SAN JOSE,PEREZ ZELEDON,SAN MARTIN (LAS MULAS)                            
119078,SAN JOSE,PEREZ ZELEDON,GUADALUPE                                         
119079,SAN JOSE,PEREZ ZELEDON,RIO GRANDE                                        
119080,SAN JOSE,PEREZ ZELEDON,LA PIEDRA DE RIVAS                                
119081,SAN JOSE,PEREZ ZELEDON,PAVONES                                           
119082,SAN JOSE,PEREZ ZELEDON,EL HOYON                                          
119083,SAN JOSE,PEREZ ZELEDON,SINAI                                             
119084,SAN JOSE,PEREZ ZELEDON,VALENCIA                                          
119085,SAN JOSE,PEREZ ZELEDON,MIRAVALLES                                        
119086,SAN JOSE,PEREZ ZELEDON,TRINIDAD                                          
119087,SAN JOSE,PEREZ ZELEDON,VERACRUZ                                          
119088,SAN JOSE,PEREZ ZELEDON,MOLLEJONES                                        
119089,SAN JOSE,PEREZ ZELEDON,SOCORRO                                           
119090,SAN JOSE,PEREZ ZELEDON,LOS ANGELES DE LIGIA                              
119091,SAN JOSE,PEREZ ZELEDON,VILLANUEVA DE PEDREGOSO                           
119092,SAN JOSE,PEREZ ZELEDON,SANTA EDUVIGIS                                    
119093,SAN JOSE,PEREZ ZELEDON,SAGRADA FAMILIA                                   
119094,SAN JOSE,PEREZ ZELEDON,ROSARIO O ARRONIS                                 
119095,SAN JOSE,PEREZ ZELEDON,MIRAFLORES                                        
119096,SAN JOSE,PEREZ ZELEDON,PALMITAL                                          
119097,SAN JOSE,PEREZ ZELEDON,SANTIAGO                                          
119098,SAN JOSE,PEREZ ZELEDON,ESPERANZA DE SAN PEDRO                            
119099,SAN JOSE,PEREZ ZELEDON,VILLA ARGENTINA                                   
119100,SAN JOSE,PEREZ ZELEDON,SAN RAMON NORTE                                   
119101,SAN JOSE,PEREZ ZELEDON,JARDIN (PARTE ESTE)                               
119102,SAN JOSE,PEREZ ZELEDON,BERLIN                                            
119103,SAN JOSE,PEREZ ZELEDON,BAJO ESPERANZA                                    
119104,SAN JOSE,PEREZ ZELEDON,PILAR                                             
119105,SAN JOSE,PEREZ ZELEDON,CAI. ANTONIO BASTIDA DE PAZ                       
119106,SAN JOSE,PEREZ ZELEDON,CRISTO REY                                        
119107,SAN JOSE,PEREZ ZELEDON,CALIFORNIA DE RIO NUEVO                           
119108,SAN JOSE,PEREZ ZELEDON,HLE. MONS.DELFIN QUESADA CASTRO                   
119109,SAN JOSE,PEREZ ZELEDON,PIEDRA ALTA                                       
119110,SAN JOSE,PEREZ ZELEDON,BONITA                                            
119111,SAN JOSE,PEREZ ZELEDON,CENIZA                                            
119112,SAN JOSE,PEREZ ZELEDON,COCORI                                            
119113,SAN JOSE,PEREZ ZELEDON,COOPERATIVA                                       
119114,SAN JOSE,PEREZ ZELEDON,INVU PEDRO PEREZ                                  
119115,SAN JOSE,PEREZ ZELEDON,MORAZAN                                           
119116,SAN JOSE,PEREZ ZELEDON,SAN ANDRES                                        
119117,SAN JOSE,PEREZ ZELEDON,TIERRA PROMETIDA                                  
119118,SAN JOSE,PEREZ ZELEDON,BAIDAMBU                                          
119119,SAN JOSE,PEREZ ZELEDON,LA AURORA                                         
119120,SAN JOSE,PEREZ ZELEDON,TIRRA                                             
119121,SAN JOSE,PEREZ ZELEDON,RIO QUEBRADAS ARRIBA                              
119122,SAN JOSE,PEREZ ZELEDON,DANIEL FLORES                                     
119123,SAN JOSE,PEREZ ZELEDON,SAN GERARDO                                       
119124,SAN JOSE,PEREZ ZELEDON,UAI. PABRU PRESBERE                               
119125,SAN JOSE,PEREZ ZELEDON,ARIZONA                                           
119126,SAN JOSE,PEREZ ZELEDON,QUEBRADA HONDA (PARTE ESTE)                       
119127,SAN JOSE,PEREZ ZELEDON,SAN JOSE                                          
119128,SAN JOSE,PEREZ ZELEDON,BAJO BONITAS                                      
119129,SAN JOSE,PEREZ ZELEDON,LOS ANGELES (BAJO ESPINOZA)                       
119130,SAN JOSE,PEREZ ZELEDON,SAN GERARDO (PARTE NORTE)                         
119131,SAN JOSE,PEREZ ZELEDON,DELICIAS                                          
119132,SAN JOSE,PEREZ ZELEDON,LAS BRISAS                                        
119133,SAN JOSE,PEREZ ZELEDON,MERCEDES ARRIBA                                   
119134,SAN JOSE,PEREZ ZELEDON,PUEBLO NUEVO                                      
119135,SAN JOSE,PEREZ ZELEDON,PENSILVANIA (SAN MARCOS)                          
119136,SAN JOSE,PEREZ ZELEDON,MOCTEZUMA                                         
119137,SAN JOSE,PEREZ ZELEDON,SAN ANTONIO ABAJO                                 
120001,SAN JOSE,LEON CORTES CASTRO,SAN PABLO                                    
120002,SAN JOSE,LEON CORTES CASTRO,SAN ANDRES                                   
120003,SAN JOSE,LEON CORTES CASTRO,LLANO BONITO (SAN RAFAEL ARRIBA)             
120004,SAN JOSE,LEON CORTES CASTRO,SAN ISIDRO                                   
120005,SAN JOSE,LEON CORTES CASTRO,SANTA CRUZ                                   
120006,SAN JOSE,LEON CORTES CASTRO,ANGOSTURA ABAJO                              
120007,SAN JOSE,LEON CORTES CASTRO,SAN RAFAEL ABAJO (BENEFICIO CAFE)            
120008,SAN JOSE,LEON CORTES CASTRO,SANTA ROSA ABAJO ESTE                        
120009,SAN JOSE,LEON CORTES CASTRO,CEDRAL PARTE NORTE                           
120011,SAN JOSE,LEON CORTES CASTRO,SAN FRANCISCO                                
120012,SAN JOSE,LEON CORTES CASTRO,TRINIDAD                                     
120013,SAN JOSE,LEON CORTES CASTRO,SAN MARTIN                                   
120014,SAN JOSE,LEON CORTES CASTRO,LA LUCHA (SUR DEL RIO)                       
120015,SAN JOSE,LEON CORTES CASTRO,SAN ANTONIO                                  
120016,SAN JOSE,LEON CORTES CASTRO,HIGUERON                                     
120017,SAN JOSE,LEON CORTES CASTRO,LA CUESTA O BAJO DE TARRAZU                  
120018,SAN JOSE,LEON CORTES CASTRO,CARRIZALES                                   
120019,SAN JOSE,LEON CORTES CASTRO,SANTA JUANA                                  
120020,SAN JOSE,LEON CORTES CASTRO,SANTA ROSA ARRIBA ESTE                       
201001,ALAJUELA,CENTRAL,ALAJUELA                                                
201002,ALAJUELA,CENTRAL,CONCEPCION O EL LLANO                                   
201003,ALAJUELA,CENTRAL,CANOAS                                                  
201004,ALAJUELA,CENTRAL,SAN JOSE                                                
201005,ALAJUELA,CENTRAL,EL COYOL                                                
201006,ALAJUELA,CENTRAL,TUETAL SUR                                              
201007,ALAJUELA,CENTRAL,CARRIZAL                                                
201008,ALAJUELA,CENTRAL,UJARRAS                                                 
201009,ALAJUELA,CENTRAL,SAN ANTONIO DEL TEJAR                                   
201010,ALAJUELA,CENTRAL,EL ROBLE                                                
201011,ALAJUELA,CENTRAL,GUACIMA (SANTIAGO OESTE)                                
201012,ALAJUELA,CENTRAL,EL COCO                                                 
201013,ALAJUELA,CENTRAL,LAS VUELTAS                                             
201014,ALAJUELA,CENTRAL,SAN ISIDRO                                              
201015,ALAJUELA,CENTRAL,ITIQUIS                                                 
201016,ALAJUELA,CENTRAL,DULCE NOMBRE DE LAGUNA                                  
201017,ALAJUELA,CENTRAL,SABANILLA                                               
201018,ALAJUELA,CENTRAL,SAN LUIS                                                
201019,ALAJUELA,CENTRAL,LOS ANGELES                                             
201020,ALAJUELA,CENTRAL,FRAIJANES                                               
201021,ALAJUELA,CENTRAL,SAN RAFAEL ESTE                                         
201022,ALAJUELA,CENTRAL,SAN RAFAEL OESTE                                        
201024,ALAJUELA,CENTRAL,RIO SEGUNDO (SANTIAGO ESTE)                             
201025,ALAJUELA,CENTRAL,DESAMPARADOS                                            
201026,ALAJUELA,CENTRAL,TURRUCARES                                              
201027,ALAJUELA,CENTRAL,CINCO ESQUINAS                                          
201028,ALAJUELA,CENTRAL,CEBADILLA                                               
201029,ALAJUELA,CENTRAL,SAN MIGUEL O CERRILLOS                                  
201030,ALAJUELA,CENTRAL,TAMBOR (SANTA ANA)                                      
201031,ALAJUELA,CENTRAL,CACAO                                                   
201032,ALAJUELA,CENTRAL,TUETAL NORTE (PARTE)                                    
201033,ALAJUELA,CENTRAL, GARITA                                                 
201034,ALAJUELA,CENTRAL,POASITO                                                 
201035,ALAJUELA,CENTRAL,SAN MIGUEL DE SARAPIQUI                                 
201036,ALAJUELA,CENTRAL,PAVAS (GUARARI)                                         
201037,ALAJUELA,CENTRAL,SAN MARTIN                                              
201039,ALAJUELA,CENTRAL,SIQUIARES                                               
201040,ALAJUELA,CENTRAL,CORAZON DE JESUS                                        
201041,ALAJUELA,CENTRAL,EL CERRO                                                
201042,ALAJUELA,CENTRAL,VILLA BONITA (PARTE SUR)                                
201043,ALAJUELA,CENTRAL,CIRUELAS                                                
201044,ALAJUELA,CENTRAL,CACIQUE                                                 
201045,ALAJUELA,CENTRAL,DULCE NOMBRE O LAS ANIMAS                               
201046,ALAJUELA,CENTRAL,PUEBLO NUEVO                                            
201047,ALAJUELA,CENTRAL,MONTECILLOS (PARTE NORTE)                               
201048,ALAJUELA,CENTRAL,NUESTRO AMO                                             
201049,ALAJUELA,CENTRAL,INVU LOS RODRIGUEZ                                      
201050,ALAJUELA,CENTRAL,TACACORI                                                
201051,ALAJUELA,CENTRAL,PACTO DEL JOCOTE                                        
201052,ALAJUELA,CENTRAL,CERRILLAL                                               
201053,ALAJUELA,CENTRAL,VILLA HELIA (FINCA HELIA)                               
201054,ALAJUELA,CENTRAL,QUEBRADAS                                               
201055,ALAJUELA,CENTRAL,ROSALES                                                 
201056,ALAJUELA,CENTRAL,CALIFORNIA                                              
201057,ALAJUELA,CENTRAL,LAS PILAS                                               
201058,ALAJUELA,CENTRAL,CAI. REYNALDO ZU�IGA VILLALOBOS                         
201059,ALAJUELA,CENTRAL,CAI. LUIS PAULINO MORA MORA                             
201060,ALAJUELA,CENTRAL,CAI. JORGE ART. M. C (AMBITOS A,B)                      
201062,ALAJUELA,CENTRAL,CAI.JORGE ART. MONT. CAS. (AMB. C)                      
201063,ALAJUELA,CENTRAL,CAI.JORGE ART. MONT. CAS. (AMB. D)                      
201064,ALAJUELA,CENTRAL,CAI. GERARDO RODRIGUEZ ECHEVERRIA                       
201065,ALAJUELA,CENTRAL,CAI. ADULTO MAYOR                                       
201066,ALAJUELA,CENTRAL,HLE. SANTIAGO CRESPO CALVO                              
201067,ALAJUELA,CENTRAL,BARRIO CORAZON DE JESUS                                 
201068,ALAJUELA,CENTRAL,EL ARROYO                                               
201069,ALAJUELA,CENTRAL,EL CARMEN                                               
201070,ALAJUELA,CENTRAL,RINCON CHIQUITO                                         
201071,ALAJUELA,CENTRAL,CAE. OFELIA VINCEZI PE�ARANDA                           
201072,ALAJUELA,CENTRAL,EL PARAISO                                              
201073,ALAJUELA,CENTRAL,RINCON DE HERRERA                                       
201074,ALAJUELA,CENTRAL,CAI.JORGE ART. MONT. CAS. (AMB. E)                      
201075,ALAJUELA,CENTRAL,CENTRO NAC. DE ATENCION ESPECIFIC.                      
201076,ALAJUELA,CENTRAL,CAI. TERRAZAS (MODULOS A-B-C-D)                         
201077,ALAJUELA,CENTRAL,CAI. JORGE ARTURO MONTERO (F-ARCOS                      
202001,ALAJUELA,SAN RAMON,SAN RAMON                                             
202002,ALAJUELA,SAN RAMON,SANTIAGO                                              
202003,ALAJUELA,SAN RAMON,SAN JOSE (RIO JESUS)                                  
202004,ALAJUELA,SAN RAMON,SAN JUAN                                              
202005,ALAJUELA,SAN RAMON,PIEDADES NORTE                                        
202006,ALAJUELA,SAN RAMON,LA PAZ                                                
202007,ALAJUELA,SAN RAMON,PIEDADES SUR                                          
202008,ALAJUELA,SAN RAMON,SALVADOR                                              
202009,ALAJUELA,SAN RAMON,SAN FRANCISCO                                         
202010,ALAJUELA,SAN RAMON,SAN MIGUEL                                            
202011,ALAJUELA,SAN RAMON,BUREAL                                                
202012,ALAJUELA,SAN RAMON,SAN RAFAEL                                            
202013,ALAJUELA,SAN RAMON,BERLIN                                                
202014,ALAJUELA,SAN RAMON,CALLE ZAMORA                                          
202015,ALAJUELA,SAN RAMON,LLANO DE BRENES                                       
202016,ALAJUELA,SAN RAMON,SAN ISIDRO                                            
202017,ALAJUELA,SAN RAMON,LOS ANGELES SUR                                       
202018,ALAJUELA,SAN RAMON,BAJO CORDOBA                                          
202019,ALAJUELA,SAN RAMON,SAN PEDRO                                             
202020,ALAJUELA,SAN RAMON,VOLIO                                                 
202021,ALAJUELA,SAN RAMON,ALTO VILLEGAS                                         
202022,ALAJUELA,SAN RAMON,CONCEPCION                                            
202023,ALAJUELA,SAN RAMON,SAN ANTONIO DE ZAPOTAL                                
202024,ALAJUELA,SAN RAMON,SAN ISIDRO DE PE�AS BLANCAS                           
202025,ALAJUELA,SAN RAMON,CARRERA BUENA                                         
202026,ALAJUELA,SAN RAMON,BOLIVAR (ESPERANZA)                                   
202027,ALAJUELA,SAN RAMON,LA ESPERANZA                                          
202028,ALAJUELA,SAN RAMON,CHACHAGUA                                             
202029,ALAJUELA,SAN RAMON,BAJO DE LOS RODRIGUEZ                                 
202030,ALAJUELA,SAN RAMON,COLONIA TRINIDAD                                      
202031,ALAJUELA,SAN RAMON,LOS CRIQUES                                           
202032,ALAJUELA,SAN RAMON,BAJO LA PAZ                                           
202034,ALAJUELA,SAN RAMON,GUARIA (RIO GRANDE)                                   
202035,ALAJUELA,SAN RAMON,SECTOR LOS ANGELES                                    
202036,ALAJUELA,SAN RAMON,CATARATA                                              
202037,ALAJUELA,SAN RAMON,VALLE AZUL                                            
202038,ALAJUELA,SAN RAMON,BAJO ZU�IGA                                           
202039,ALAJUELA,SAN RAMON,SOCORRO                                               
202040,ALAJUELA,SAN RAMON,LA GUARIA                                             
202041,ALAJUELA,SAN RAMON,ANGOSTURA                                             
202042,ALAJUELA,SAN RAMON,EL CASTILLO                                           
202044,ALAJUELA,SAN RAMON,ZAPOTAL PARTE ESTE                                    
202045,ALAJUELA,SAN RAMON,HLE. SAN RAMON                                        
202046,ALAJUELA,SAN RAMON,CIUDADELA JARDINES                                    
202047,ALAJUELA,SAN RAMON,CALLE LEON                                            
202048,ALAJUELA,SAN RAMON,EMPALME                                               
202049,ALAJUELA,SAN RAMON,SAN MARTIN (EL BOSQUE)                                
202050,ALAJUELA,SAN RAMON,BARRIO BELEN                                          
202051,ALAJUELA,SAN RAMON,LA BALSA                                              
203001,ALAJUELA,GRECIA,GRECIA                                                   
203002,ALAJUELA,GRECIA,MESON O DULCE NOMBRE                                     
203003,ALAJUELA,GRECIA,SAN FRANCISCO                                            
203004,ALAJUELA,GRECIA,SAN JOSE Y SANTA GERTRUDIS NORTE                         
203005,ALAJUELA,GRECIA,SANTA GERTRUDIS SUR                                      
203007,ALAJUELA,GRECIA,SAN ROQUE                                                
203008,ALAJUELA,GRECIA,TACARES                                                  
203009,ALAJUELA,GRECIA,RINCON DE ARIAS                                          
203012,ALAJUELA,GRECIA,LA ARENA (PARTE NORTE)                                   
203014,ALAJUELA,GRECIA,CALLE RODRIGUEZ                                          
203015,ALAJUELA,GRECIA,CATALU�A                                                 
203017,ALAJUELA,GRECIA,PUENTE DE PIEDRA                                         
203018,ALAJUELA,GRECIA,RINCON DE SALAS                                          
203019,ALAJUELA,GRECIA,LOS ANGELES DE BOLIVAR                                   
203020,ALAJUELA,GRECIA,SAN JUAN                                                 
203022,ALAJUELA,GRECIA,SAN LUIS                                                 
203023,ALAJUELA,GRECIA,SAN MIGUEL                                               
203025,ALAJUELA,GRECIA,LOS LOTES (SAN VICENTE)                                  
203026,ALAJUELA,GRECIA,BODEGAS                                                  
203027,ALAJUELA,GRECIA,ALTOS DE PERALTA                                         
203028,ALAJUELA,GRECIA,BARRIO LATINO (AGUALOTE)                                 
203029,ALAJUELA,GRECIA,CAJON (BARRIO SAN JOSE)                                  
203032,ALAJUELA,GRECIA,CARBONAL (CRISTO REY)                                    
203033,ALAJUELA,GRECIA,CALLE SAN JOSE                                           
203034,ALAJUELA,GRECIA,SAN MIGUEL ARRIBA                                        
203035,ALAJUELA,GRECIA,CALLE ACHIOTE                                            
203036,ALAJUELA,GRECIA,SAN ISIDRO                                               
203037,ALAJUELA,GRECIA,CEDRO                                                    
203038,ALAJUELA,GRECIA,PORO                                                     
203039,ALAJUELA,GRECIA,LEON CORTES CASTRO                                       
203043,ALAJUELA,GRECIA,BAJO ROSALES                                             
203044,ALAJUELA,GRECIA,CAJON ARRIBA                                             
203045,ALAJUELA,GRECIA,HLE. JAFETH JIMENEZ MORALES                              
203047,ALAJUELA,GRECIA,LA ARGENTINA                                             
204001,ALAJUELA,SAN MATEO,SAN MATEO                                             
204002,ALAJUELA,SAN MATEO,HIGUITO                                               
204003,ALAJUELA,SAN MATEO,MADERAL                                               
204004,ALAJUELA,SAN MATEO,DULCE NOMBRE                                          
204005,ALAJUELA,SAN MATEO,DESMONTE                                              
204008,ALAJUELA,SAN MATEO,JESUS MARIA                                           
204009,ALAJUELA,SAN MATEO,LABRADOR                                              
204010,ALAJUELA,SAN MATEO,ESTANQUILLOS O SAN ANTONIO (P.O.)                     
205001,ALAJUELA,ATENAS,ATENAS                                                   
205002,ALAJUELA,ATENAS,LOS ANGELES                                              
205003,ALAJUELA,ATENAS,JESUS                                                    
205004,ALAJUELA,ATENAS,SABANA LARGA                                             
205006,ALAJUELA,ATENAS,ESCOBAL                                                  
205007,ALAJUELA,ATENAS,MERCEDES                                                 
205008,ALAJUELA,ATENAS,GUACIMO                                                  
205009,ALAJUELA,ATENAS,SAN ISIDRO                                               
205010,ALAJUELA,ATENAS,RINCON DE SAN ISIDRO                                     
205011,ALAJUELA,ATENAS,CONCEPCION                                               
205012,ALAJUELA,ATENAS,BALSA                                                    
205013,ALAJUELA,ATENAS,SAN JOSE SUR                                             
205014,ALAJUELA,ATENAS,SANTA EULALIA                                            
205015,ALAJUELA,ATENAS,MORAZAN                                                  
205016,ALAJUELA,ATENAS,HLE. HORTENSIA RODRIGUEZ S.DE B                          
205017,ALAJUELA,ATENAS,ESTANQUILLO (SAN ANTONIO) (P.EST.)                       
206001,ALAJUELA,NARANJO,NARANJO                                                 
206002,ALAJUELA,NARANJO,CANDELARIA (BAJO CORRALES)                              
206003,ALAJUELA,NARANJO,SAN ANTONIO DE LA CUEVA                                 
206004,ALAJUELA,NARANJO,SAN JUAN (ACEQUIA GRANDE)                               
206005,ALAJUELA,NARANJO,SAN MIGUEL                                              
206006,ALAJUELA,NARANJO,PALMITOS                                                
206007,ALAJUELA,NARANJO,CONCEPCION ESTE                                         
206008,ALAJUELA,NARANJO,ROSARIO (EL HOYO)                                       
206009,ALAJUELA,NARANJO,SAN JOSE (SAN JUANILLO)                                 
206010,ALAJUELA,NARANJO,BARRANCA                                                
206011,ALAJUELA,NARANJO,SAN ANTONIO DE BARRANCA                                 
206012,ALAJUELA,NARANJO,CIRRI SUR                                               
206013,ALAJUELA,NARANJO,LLANO BONITO O CIRRI NORTE                              
206014,ALAJUELA,NARANJO,SAN ROQUE                                               
206015,ALAJUELA,NARANJO,CA�UELA ARRIBA                                          
206016,ALAJUELA,NARANJO,SAN JERONIMO                                            
206017,ALAJUELA,NARANJO,LOS ROBLES                                              
206018,ALAJUELA,NARANJO,SAN FRANCISCO (VACA MUERTA)                             
206019,ALAJUELA,NARANJO,COMUN O SAN RAFAEL                                      
206020,ALAJUELA,NARANJO,LOURDES                                                 
206021,ALAJUELA,NARANJO,DULCE NOMBRE (VILLANO)                                  
206022,ALAJUELA,NARANJO,HLE. JOSE DEL OLMO                                      
206023,ALAJUELA,NARANJO,SANTA MARGARITA                                         
207001,ALAJUELA,PALMARES,PALMARES                                               
207002,ALAJUELA,PALMARES,ZARAGOZA                                               
207003,ALAJUELA,PALMARES,RINCON DE ZARAGOZA                                     
207004,ALAJUELA,PALMARES,BUENOS AIRES                                           
207005,ALAJUELA,PALMARES,LA GRANJA                                              
207006,ALAJUELA,PALMARES,SANTIAGO                                               
207007,ALAJUELA,PALMARES,CANDELARIA                                             
207008,ALAJUELA,PALMARES,ESQUIPULAS                                             
207009,ALAJUELA,PALMARES,HLE. PALMARES                                          
207010,ALAJUELA,PALMARES,COCALECA (PARTE OESTE)                                 
207011,ALAJUELA,PALMARES,CALLE VARGAS (PARTE SUR)                               
208001,ALAJUELA,POAS,SAN PEDRO                                                  
208002,ALAJUELA,POAS,SAN JUAN SUR                                               
208003,ALAJUELA,POAS,SAN RAFAEL                                                 
208004,ALAJUELA,POAS,CARRILLOS BAJO                                             
208005,ALAJUELA,POAS,SABANA REDONDA                                             
208006,ALAJUELA,POAS,SANTA ROSA                                                 
208007,ALAJUELA,POAS,CHILAMATE                                                  
208008,ALAJUELA,POAS,SAN JUAN NORTE                                             
208010,ALAJUELA,POAS,CARRILLOS ALTO                                             
208011,ALAJUELA,POAS,GUATUZA                                                    
208012,ALAJUELA,POAS,EL SITIO (PARTE OESTE)                                     
209001,ALAJUELA,OROTINA,OROTINA                                                 
209002,ALAJUELA,OROTINA,EL MASTATE                                              
209003,ALAJUELA,OROTINA,HACIENDA VIEJA                                          
209004,ALAJUELA,OROTINA,COYOLAR                                                 
209005,ALAJUELA,OROTINA,CASCAJAL                                                
209006,ALAJUELA,OROTINA,NUEVA SANTA RITA                                        
209007,ALAJUELA,OROTINA,CUATRO ESQUINAS NORTE                                   
209009,ALAJUELA,OROTINA,LA CEIBA                                                
209010,ALAJUELA,OROTINA,SAN JERONIMO                                            
209011,ALAJUELA,OROTINA,PARCELAS TRINIDAD (UVITA)                               
209012,ALAJUELA,OROTINA,HLE. PRESBITERO JESUS MARIA VARGAS                      
210001,ALAJUELA,SAN CARLOS,QUESADA                                              
210002,ALAJUELA,SAN CARLOS,DULCE NOMBRE                                         
210003,ALAJUELA,SAN CARLOS,SUCRE                                                
210004,ALAJUELA,SAN CARLOS,FLORENCIA                                            
210005,ALAJUELA,SAN CARLOS,QUEBRADA AZUL                                        
210006,ALAJUELA,SAN CARLOS,MUELLE DE SAN CARLOS                                 
210008,ALAJUELA,SAN CARLOS,SANTA CLARA                                          
210009,ALAJUELA,SAN CARLOS,LA VEGA O CUATRO ESQUINAS                            
210010,ALAJUELA,SAN CARLOS,BUENAVISTA                                           
210011,ALAJUELA,SAN CARLOS,AGUAS ZARCAS                                         
210012,ALAJUELA,SAN CARLOS,LOS CHILES                                           
210013,ALAJUELA,SAN CARLOS,LA TIGRA                                             
210014,ALAJUELA,SAN CARLOS,LA PALMERA                                           
210015,ALAJUELA,SAN CARLOS,PITAL                                                
210016,ALAJUELA,SAN CARLOS,LA UNION ESTE                                        
210017,ALAJUELA,SAN CARLOS,VENECIA                                              
210018,ALAJUELA,SAN CARLOS,SAN VICENTE                                          
210019,ALAJUELA,SAN CARLOS,PORVENIR                                             
210020,ALAJUELA,SAN CARLOS,BOCA DE ARENAL                                       
210021,ALAJUELA,SAN CARLOS,LA FORTUNA                                           
210022,ALAJUELA,SAN CARLOS,EL TANQUE                                            
210023,ALAJUELA,SAN CARLOS,GUARIA DE FORTUNA                                    
210024,ALAJUELA,SAN CARLOS,PLATANAR                                             
210025,ALAJUELA,SAN CARLOS,SAN JUAN DE QUEBRADA DE PALO                         
210026,ALAJUELA,SAN CARLOS,VERACRUZ                                             
210027,ALAJUELA,SAN CARLOS,SANTO DOMINGO                                        
210028,ALAJUELA,SAN CARLOS,SAN FRANCISCO O VACA BLANCA                          
210029,ALAJUELA,SAN CARLOS,LOS LLANOS O ALTAMIRITA                              
210030,ALAJUELA,SAN CARLOS,LA VIEJA                                             
210031,ALAJUELA,SAN CARLOS,SAN RAFAEL DE PLATANAR                               
210032,ALAJUELA,SAN CARLOS,SAN PEDRO Y TABLA GRANDE                             
210033,ALAJUELA,SAN CARLOS,AGUA AZUL                                            
210035,ALAJUELA,SAN CARLOS,LOS ANGELES                                          
210036,ALAJUELA,SAN CARLOS,VENADO                                               
210037,ALAJUELA,SAN CARLOS,JICARITO                                             
210038,ALAJUELA,SAN CARLOS,BUENOS AIRES                                         
210040,ALAJUELA,SAN CARLOS,MONTELIMAR                                           
210041,ALAJUELA,SAN CARLOS,SAN JOSECITO DE CUTRIS                               
210042,ALAJUELA,SAN CARLOS,SAN GERARDO DE POCOSOL                               
210043,ALAJUELA,SAN CARLOS,SAN JOAQUIN                                          
210045,ALAJUELA,SAN CARLOS,CORAZON DE JESUS                                     
210046,ALAJUELA,SAN CARLOS,LA UNION                                             
210047,ALAJUELA,SAN CARLOS,SAHINO O SAN JORGE                                   
210048,ALAJUELA,SAN CARLOS,LA LEGUA                                             
210049,ALAJUELA,SAN CARLOS,SAN GERARDO                                          
210050,ALAJUELA,SAN CARLOS,LA MARINA                                            
210051,ALAJUELA,SAN CARLOS,CEDRAL                                               
210052,ALAJUELA,SAN CARLOS,CHAMBACU DE MONTERREY                                
210053,ALAJUELA,SAN CARLOS,SAN RAMON (CARIBLANCA)                               
210054,ALAJUELA,SAN CARLOS,SAN JOSE DE LA TIGRA                                 
210055,ALAJUELA,SAN CARLOS,SAN PEDRO DE LA TIGRA                                
210056,ALAJUELA,SAN CARLOS,SAN MIGUEL O LIMBO                                   
210057,ALAJUELA,SAN CARLOS,EL CONCHO                                            
210058,ALAJUELA,SAN CARLOS,SAN ROQUE                                            
210059,ALAJUELA,SAN CARLOS,SANTA ROSA DE POCOSOL                                
210060,ALAJUELA,SAN CARLOS,BELLA VISTA                                          
210061,ALAJUELA,SAN CARLOS,LAS BRISAS                                           
210062,ALAJUELA,SAN CARLOS,SANTA RITA                                           
210063,ALAJUELA,SAN CARLOS,BOCA TAPADA                                          
210064,ALAJUELA,SAN CARLOS,COOPEVEGA                                            
210065,ALAJUELA,SAN CARLOS,PITALITO                                             
210066,ALAJUELA,SAN CARLOS,LOS ANGELES DE PITAL                                 
210067,ALAJUELA,SAN CARLOS,ESTERITO                                             
210068,ALAJUELA,SAN CARLOS,SANTA MARIA                                          
210069,ALAJUELA,SAN CARLOS,SAN DIEGO                                            
210070,ALAJUELA,SAN CARLOS,MORAVIA                                              
210071,ALAJUELA,SAN CARLOS,CARRIZAL                                             
210072,ALAJUELA,SAN CARLOS,SAN JUAN DE LA CEIBA                                 
210073,ALAJUELA,SAN CARLOS,EL PLOMO                                             
210074,ALAJUELA,SAN CARLOS,SAN MARCOS NORTE                                     
210075,ALAJUELA,SAN CARLOS,MARSELLA                                             
210076,ALAJUELA,SAN CARLOS,ACAPULCO                                             
210077,ALAJUELA,SAN CARLOS,SAN FRANCISCO O LA AQUILEA                           
210078,ALAJUELA,SAN CARLOS,LINDA VISTA                                          
210079,ALAJUELA,SAN CARLOS,LA GLORIA O SAN MARCOS                               
210080,ALAJUELA,SAN CARLOS,GUARIA DE POCOSOL                                    
210081,ALAJUELA,SAN CARLOS,SONAFLUCA                                            
210082,ALAJUELA,SAN CARLOS,SANTA FE O LA FAMA                                   
210083,ALAJUELA,SAN CARLOS,SAN JORGE DE CUTRIS                                  
210084,ALAJUELA,SAN CARLOS,DELICIAS                                             
210085,ALAJUELA,SAN CARLOS,SAN BOSCO                                            
210086,ALAJUELA,SAN CARLOS,ALMENDROS                                            
210088,ALAJUELA,SAN CARLOS,BUENOS AIRES DE VENECIA                              
210089,ALAJUELA,SAN CARLOS,SAN MARTIN                                           
210090,ALAJUELA,SAN CARLOS,CERRO CORTES                                         
210091,ALAJUELA,SAN CARLOS,PALMAR                                               
210092,ALAJUELA,SAN CARLOS,SAN CRISTOBAL                                        
210093,ALAJUELA,SAN CARLOS,CAI. NELSON MANDELA                                  
210094,ALAJUELA,SAN CARLOS,HLE. SAN VICENTE DE PAUL                             
210095,ALAJUELA,SAN CARLOS,ABUNDANCIA                                           
210096,ALAJUELA,SAN CARLOS,SAN JOSE DE LA MONTA�A                               
210097,ALAJUELA,SAN CARLOS,SAN PABLO                                            
210098,ALAJUELA,SAN CARLOS,CONCEPCION                                           
210099,ALAJUELA,SAN CARLOS,EL CORTE (SANTA ROSA)                                
210100,ALAJUELA,SAN CARLOS,CARMEN                                               
210101,ALAJUELA,SAN CARLOS,TRES Y TRES                                          
210102,ALAJUELA,SAN CARLOS,SANTA ELENA                                          
210103,ALAJUELA,SAN CARLOS,CORAZON DE JESUS DE LA TESALIA                       
210104,ALAJUELA,SAN CARLOS,COREA O CONCEPCION                                   
210105,ALAJUELA,SAN CARLOS,LA LUCHA                                             
211001,ALAJUELA,ZARCERO,ZARCERO                                                 
211002,ALAJUELA,ZARCERO,LAGUNA                                                  
211003,ALAJUELA,ZARCERO,TAPESCO                                                 
211004,ALAJUELA,ZARCERO,SANTA ROSA                                              
211005,ALAJUELA,ZARCERO,GUADALUPE                                               
211006,ALAJUELA,ZARCERO,SAN LUIS O MORELOS                                      
211007,ALAJUELA,ZARCERO,PALMIRA                                                 
211008,ALAJUELA,ZARCERO,ZAPOTE                                                  
211009,ALAJUELA,ZARCERO,PUEBLO NUEVO DE LA PICADA                               
211010,ALAJUELA,ZARCERO,SAN JUAN DE LAJAS                                       
211011,ALAJUELA,ZARCERO,LEGUA                                                   
211012,ALAJUELA,ZARCERO,HLE. SAN RAFAEL                                         
211013,ALAJUELA,ZARCERO,ANATERI                                                 
212001,ALAJUELA,SARCHI,SARCHI NORTE                                             
212002,ALAJUELA,SARCHI,SARCHI SUR                                               
212003,ALAJUELA,SARCHI,SAN PEDRO                                                
212004,ALAJUELA,SARCHI,BAJOS DEL TORO                                           
212005,ALAJUELA,SARCHI,SAN JUAN                                                 
212006,ALAJUELA,SARCHI,INVU (LOS ANGELES)                                       
212007,ALAJUELA,SARCHI,SAN JOSE DE TROJAS                                       
212008,ALAJUELA,SARCHI,LA LUISA                                                 
212009,ALAJUELA,SARCHI,SABANILLA                                                
213001,ALAJUELA,UPALA,UPALA                                                     
213002,ALAJUELA,UPALA,SAN ISIDRO DE ZAPOTE                                      
213003,ALAJUELA,UPALA,COLONIA PUNTARENAS                                        
213004,ALAJUELA,UPALA,CANALETE                                                  
213005,ALAJUELA,UPALA,SAN ISIDRO DE AGUAS CLARAS                                
213006,ALAJUELA,UPALA,COLONIA LIBERTAD                                          
213007,ALAJUELA,UPALA,CUATRO BOCAS                                              
213008,ALAJUELA,UPALA,SAN JOSE O PIZOTE                                         
213009,ALAJUELA,UPALA,BIJAGUA                                                   
213010,ALAJUELA,UPALA,SANTO DOMINGO                                             
213011,ALAJUELA,UPALA,DELICIAS                                                  
213012,ALAJUELA,UPALA,SANTA CLARA (PARTE ESTE)                                  
213013,ALAJUELA,UPALA,DOS RIOS O COLONIA MAYORGA                                
213014,ALAJUELA,UPALA,BRASILIA                                                  
213015,ALAJUELA,UPALA,PATA DE GALLO (PARTE NORTE)                               
213016,ALAJUELA,UPALA,GUAYABAL O EL CARMEN                                      
213017,ALAJUELA,UPALA,SAN LUIS                                                  
213018,ALAJUELA,UPALA,SAN JORGE O RIO NEGRO                                     
213020,ALAJUELA,UPALA,SAN RAMON                                                 
213021,ALAJUELA,UPALA,AGUAS CLARAS                                              
213022,ALAJUELA,UPALA,BUENOS AIRES                                              
213023,ALAJUELA,UPALA,BIRMANIA                                                  
213024,ALAJUELA,UPALA,LAS BRISAS (MIRAMAR)                                      
213025,ALAJUELA,UPALA,SANTA ROSA (CHIMURRIA ARRIBA)                             
213026,ALAJUELA,UPALA,VILLANUEVA                                                
213027,ALAJUELA,UPALA,PORVENIR                                                  
213028,ALAJUELA,UPALA,NAZARETH                                                  
213029,ALAJUELA,UPALA,MORENO CA�AS                                              
213030,ALAJUELA,UPALA,COLONIA BLANCA                                            
213031,ALAJUELA,UPALA,LLANO AZUL                                                
213032,ALAJUELA,UPALA,SAN RAFAEL O CHIMURRIA ABAJO                              
213033,ALAJUELA,UPALA,CARTAGOS SUR                                              
213034,ALAJUELA,UPALA,QUEBRADON                                                 
213035,ALAJUELA,UPALA,LAS ARMENIAS                                              
213036,ALAJUELA,UPALA,CARTAGOS NORTE                                            
213037,ALAJUELA,UPALA,AMERICA                                                   
213038,ALAJUELA,UPALA,BETANIA                                                   
213039,ALAJUELA,UPALA,PROGRESO                                                  
213040,ALAJUELA,UPALA,EL SALTO                                                  
213041,ALAJUELA,UPALA,LAS FLORES                                                
213042,ALAJUELA,UPALA,RIO NEGRO                                                 
213043,ALAJUELA,UPALA,HIGUERON (PARTE SUR)                                      
214001,ALAJUELA,LOS CHILES,LOS CHILES                                           
214002,ALAJUELA,LOS CHILES,ARCO IRIS                                            
214003,ALAJUELA,LOS CHILES,CA�O NEGRO                                           
214004,ALAJUELA,LOS CHILES,SAN JOSE DEL AMPARO                                  
214005,ALAJUELA,LOS CHILES,PORVENIR DE SAN JORGE                                
214006,ALAJUELA,LOS CHILES,MEDIO QUESO                                          
214008,ALAJUELA,LOS CHILES,VERACRUZ                                             
214009,ALAJUELA,LOS CHILES,CUATRO ESQUINAS                                      
214010,ALAJUELA,LOS CHILES,SANTA ELENA DE ISLA CHICA                            
214011,ALAJUELA,LOS CHILES,COQUITAL                                             
214012,ALAJUELA,LOS CHILES,MONTEALEGRE                                          
214013,ALAJUELA,LOS CHILES,VASCONIA                                             
214014,ALAJUELA,LOS CHILES,LOS LIRIOS                                           
214015,ALAJUELA,LOS CHILES,SAN JORGE                                            
214016,ALAJUELA,LOS CHILES,PAVON                                                
214017,ALAJUELA,LOS CHILES,EL PARQUE                                            
214018,ALAJUELA,LOS CHILES,COBANO                                               
214019,ALAJUELA,LOS CHILES,CRISTO REY                                           
214020,ALAJUELA,LOS CHILES,LA URRACA                                            
214021,ALAJUELA,LOS CHILES,LA UNION                                             
214022,ALAJUELA,LOS CHILES,LAS NUBES                                            
215001,ALAJUELA,GUATUSO,SAN RAFAEL                                              
215002,ALAJUELA,GUATUSO,PATASTILLO                                              
215003,ALAJUELA,GUATUSO,MARGARITA                                               
215004,ALAJUELA,GUATUSO,BUENAVISTA                                              
215005,ALAJUELA,GUATUSO,CABANGA DE COTE (PUEBLO NUEVO)                          
215008,ALAJUELA,GUATUSO,PATASTE                                                 
215009,ALAJUELA,GUATUSO,MAQUENCAL O PALMITAL                                    
215010,ALAJUELA,GUATUSO,TONJIBE                                                 
215011,ALAJUELA,GUATUSO,SANTA FE                                                
215012,ALAJUELA,GUATUSO,TIALES                                                  
215013,ALAJUELA,GUATUSO,KATIRA                                                  
215014,ALAJUELA,GUATUSO,RIO CELESTE                                             
215015,ALAJUELA,GUATUSO,MONICO                                                  
215016,ALAJUELA,GUATUSO,EL VALLE                                                
215017,ALAJUELA,GUATUSO,LA GARITA                                               
215018,ALAJUELA,GUATUSO,SILENCIO                                                
216001,ALAJUELA,RIO CUARTO,COLONIA AGRICOLA DEL TORO                            
216002,ALAJUELA,RIO CUARTO,RIO CUARTO                                           
216003,ALAJUELA,RIO CUARTO,SAN RAFAEL DE RIO CUARTO(CUCARACHO                   
216004,ALAJUELA,RIO CUARTO,LA TABLA                                             
216005,ALAJUELA,RIO CUARTO,LOS ANGELES                                          
216006,ALAJUELA,RIO CUARTO,SANTA RITA                                           
216007,ALAJUELA,RIO CUARTO,SANTA ISABEL                                         
216008,ALAJUELA,RIO CUARTO,LA VICTORIA  (PARTE SUR)                             
216009,ALAJUELA,RIO CUARTO,SAN VICENTE                                          
216010,ALAJUELA,RIO CUARTO,LA ESPA�OLITA                                        
216011,ALAJUELA,RIO CUARTO,PATA DE GALLO (LOS ANGELES SUR)                      
301001,CARTAGO,CENTRAL,OCCIDENTAL                                               
301002,CARTAGO,CENTRAL,ORIENTAL                                                 
301003,CARTAGO,CENTRAL,EL CARMEN                                                
301004,CARTAGO,CENTRAL,SAN NICOLAS                                              
301005,CARTAGO,CENTRAL,SAN FRANCISCO                                            
301006,CARTAGO,CENTRAL,LOURDES                                                  
301007,CARTAGO,CENTRAL,GUADALUPE O ARENILLA                                     
301008,CARTAGO,CENTRAL,QUEBRADILLA                                              
301009,CARTAGO,CENTRAL,BERMEJO                                                  
301010,CARTAGO,CENTRAL,COPALCHI                                                 
301011,CARTAGO,CENTRAL,CORRALILLO                                               
301012,CARTAGO,CENTRAL,SAN JUAN NORTE                                           
301013,CARTAGO,CENTRAL,SAN JUAN SUR                                             
301014,CARTAGO,CENTRAL,SANTA ELENA ARRIBA                                       
301015,CARTAGO,CENTRAL,LLANO DE LOS ANGELES                                     
301016,CARTAGO,CENTRAL,SAN ANTONIO                                              
301017,CARTAGO,CENTRAL,TIERRA BLANCA                                            
301018,CARTAGO,CENTRAL,DULCE NOMBRE                                             
301019,CARTAGO,CENTRAL,NAVARRO                                                  
301020,CARTAGO,CENTRAL,LLANO GRANDE                                             
301021,CARTAGO,CENTRAL,SAN ISIDRO O EL ALUMBRE                                  
301022,CARTAGO,CENTRAL,RIO CONEJO                                               
301023,CARTAGO,CENTRAL,ALTO DE OCHOMOGO                                         
301024,CARTAGO,CENTRAL,LA LIMA                                                  
301025,CARTAGO,CENTRAL,QUIRCOT                                                  
301026,CARTAGO,CENTRAL,AZAHAR (PENJAMO)                                         
301027,CARTAGO,CENTRAL,PITAHAYA                                                 
301028,CARTAGO,CENTRAL,CABALLO BLANCO (SUR CARRETERA)                           
301029,CARTAGO,CENTRAL,SAN BLAS                                                 
301030,CARTAGO,CENTRAL,POLVORA O LOYOLA                                         
301031,CARTAGO,CENTRAL,MANUEL DE JESUS JIMENEZ                                  
301033,CARTAGO,CENTRAL,HLE. ASILO DE LA VEJEZ                                   
301034,CARTAGO,CENTRAL,LOMA LARGA                                               
301035,CARTAGO,CENTRAL,GUAYABAL (PARTE ESTE)                                    
302001,CARTAGO,PARAISO,PARAISO                                                  
302002,CARTAGO,PARAISO,BIRRISITO                                                
302003,CARTAGO,PARAISO,SANTIAGO                                                 
302004,CARTAGO,PARAISO,EL YAS                                                   
302005,CARTAGO,PARAISO,OROSI                                                    
302006,CARTAGO,PARAISO,RIO MACHO                                                
302007,CARTAGO,PARAISO,PALOMO                                                   
302008,CARTAGO,PARAISO,PURISIL                                                  
302009,CARTAGO,PARAISO,CACHI                                                    
302010,CARTAGO,PARAISO,URASCA                                                   
302011,CARTAGO,PARAISO,LA FLOR                                                  
302012,CARTAGO,PARAISO,LA LOAIZA                                                
302013,CARTAGO,PARAISO,UJARRAS                                                  
302015,CARTAGO,PARAISO,AJENJAL                                                  
302016,CARTAGO,PARAISO,ALTO DE ARAYA                                            
302017,CARTAGO,PARAISO,SAN JERONIMO O GUATUSO                                   
302018,CARTAGO,PARAISO,SAN MIGUEL O HAMACA (PARTE OESTE)                        
302019,CARTAGO,PARAISO,LAPUENTE                                                 
302020,CARTAGO,PARAISO,LLANOS DE SANTA LUCIA                                    
302021,CARTAGO,PARAISO,RIO REGADO                                               
302022,CARTAGO,PARAISO,ALEGRIA                                                  
303001,CARTAGO,LA UNION,TRES RIOS                                               
303002,CARTAGO,LA UNION,SAN DIEGO                                               
303003,CARTAGO,LA UNION,RIO AZUL                                                
303004,CARTAGO,LA UNION,SAN JUAN                                                
303005,CARTAGO,LA UNION,SAN RAFAEL                                              
303006,CARTAGO,LA UNION,CONCEPCION                                              
303007,CARTAGO,LA UNION,DULCE NOMBRE                                            
303008,CARTAGO,LA UNION,SAN RAMON                                               
303009,CARTAGO,LA UNION,SANTIAGO DEL MONTE                                      
303010,CARTAGO,LA UNION,QUEBRADA DEL FIERRO                                     
303011,CARTAGO,LA UNION,SALITRILLO                                              
303012,CARTAGO,LA UNION,RINCON MESEN (PARTE ESTE)                               
303013,CARTAGO,LA UNION,SAN VICENTE                                             
303014,CARTAGO,LA UNION,EL CARMEN                                               
303015,CARTAGO,LA UNION,VILLAS DE AYARCO                                        
303016,CARTAGO,LA UNION,YERBABUENA                                              
303017,CARTAGO,LA UNION,LINDA VISTA                                             
303018,CARTAGO,LA UNION,SAN FRANCISCO                                           
303019,CARTAGO,LA UNION,LA CIMA                                                 
304001,CARTAGO,JIMENEZ,JUAN VI�AS                                               
304002,CARTAGO,JIMENEZ,ALTO VICTORIA                                            
304004,CARTAGO,JIMENEZ,SANTA MARTA                                              
304005,CARTAGO,JIMENEZ,EL NARANJO                                               
304008,CARTAGO,JIMENEZ,TUCURRIQUE                                               
304009,CARTAGO,JIMENEZ,PEJIBAYE                                                 
304011,CARTAGO,JIMENEZ,SABANILLA                                                
304014,CARTAGO,JIMENEZ,ORIENTE                                                  
304018,CARTAGO,JIMENEZ,SAN MARTIN                                               
304019,CARTAGO,JIMENEZ,HUMO                                                     
304020,CARTAGO,JIMENEZ,LAS VUELTAS                                              
304021,CARTAGO,JIMENEZ,LOS ALPES                                                
305001,CARTAGO,TURRIALBA,TURRIALBA                                              
305002,CARTAGO,TURRIALBA,EL PORO                                                
305003,CARTAGO,TURRIALBA,AQUIARES O LA ISLA                                     
305004,CARTAGO,TURRIALBA,SAN JUAN NORTE                                         
305005,CARTAGO,TURRIALBA,SAN JUAN SUR                                           
305006,CARTAGO,TURRIALBA,LAS AMERICAS                                           
305007,CARTAGO,TURRIALBA,FLORENCIA                                              
305009,CARTAGO,TURRIALBA,EL MORA                                                
305010,CARTAGO,TURRIALBA,SANTA ROSA                                             
305011,CARTAGO,TURRIALBA,COLORADO                                               
305012,CARTAGO,TURRIALBA,TUIS                                                   
305013,CARTAGO,TURRIALBA,PACAYITAS                                              
305014,CARTAGO,TURRIALBA,LA SUIZA                                               
305015,CARTAGO,TURRIALBA,SAN JOAQUIN (CABEZA DE BUEY)                           
305016,CARTAGO,TURRIALBA,ATIRRO                                                 
305017,CARTAGO,TURRIALBA,GRANO DE ORO O XARA                                    
305018,CARTAGO,TURRIALBA,PLATANILLO                                             
305019,CARTAGO,TURRIALBA,PERALTA                                                
305020,CARTAGO,TURRIALBA,LA FLOR DE TRES EQUIS                                  
305021,CARTAGO,TURRIALBA,BONILLA ARRIBA                                         
305022,CARTAGO,TURRIALBA,PAVONES                                                
305023,CARTAGO,TURRIALBA,SITIO DE MATA                                          
305024,CARTAGO,TURRIALBA,CHITARIA                                               
305025,CARTAGO,TURRIALBA,SANTA CRUZ                                             
305026,CARTAGO,TURRIALBA,LA PASTORA                                             
305027,CARTAGO,TURRIALBA,SAN MARTIN                                             
305028,CARTAGO,TURRIALBA,SAN ANTONIO                                            
305029,CARTAGO,TURRIALBA,EL TORITO (PARTE ESTE)                                 
305030,CARTAGO,TURRIALBA,SANTA TERESITA (LAJAS)                                 
305031,CARTAGO,TURRIALBA,COLONIA GUAYABO                                        
305032,CARTAGO,TURRIALBA,TRES EQUIS                                             
305033,CARTAGO,TURRIALBA,MOLLEJONES                                             
305034,CARTAGO,TURRIALBA,ESMERALDA (PARTE ESTE)                                 
305035,CARTAGO,TURRIALBA,RECREO                                                 
305038,CARTAGO,TURRIALBA,CIMARRONES                                             
305039,CARTAGO,TURRIALBA,PALOMO                                                 
305040,CARTAGO,TURRIALBA,ESLABON                                                
305041,CARTAGO,TURRIALBA,CIEN MANZANAS                                          
305042,CARTAGO,TURRIALBA,BAJO PACUARE O SUR                                     
305043,CARTAGO,TURRIALBA,VERBENA NORTE                                          
305044,CARTAGO,TURRIALBA,SAN RAMON                                              
305045,CARTAGO,TURRIALBA,JABILLOS                                               
305046,CARTAGO,TURRIALBA,CALLE VARGAS                                           
305047,CARTAGO,TURRIALBA,ALTO VARAL                                             
305048,CARTAGO,TURRIALBA,NOCHEBUENA                                             
305049,CARTAGO,TURRIALBA,CARMEN                                                 
305050,CARTAGO,TURRIALBA,SAN VICENTE                                            
305051,CARTAGO,TURRIALBA,FUENTE                                                 
305052,CARTAGO,TURRIALBA,EL CARMEN                                              
305053,CARTAGO,TURRIALBA,SAUCE                                                  
305055,CARTAGO,TURRIALBA,JICOTEA                                                
305056,CARTAGO,TURRIALBA,SAN RAFAEL                                             
305057,CARTAGO,TURRIALBA,SIMIRI�AC (JACUY)                                      
305058,CARTAGO,TURRIALBA,ALTO PACUARE ARRIBA (DUCLAC)                           
305059,CARTAGO,TURRIALBA,JAKI (CAPILLA DOS CHIRRIPO ARRIBA)                     
305060,CARTAGO,TURRIALBA,BOLORI �AC (CAPILLA UNO)                               
305061,CARTAGO,TURRIALBA,NIMARI-�AC (RIO PEJE)                                  
305062,CARTAGO,TURRIALBA,NAMALDI                                                
305063,CARTAGO,TURRIALBA,TSIPIRI (QUEBRADA PLATANILLO)                          
305064,CARTAGO,TURRIALBA,AZUL                                                   
305065,CARTAGO,TURRIALBA,EL SILENCIO                                            
305066,CARTAGO,TURRIALBA,GUAYABO ABAJO                                          
305067,CARTAGO,TURRIALBA,CARMEN LYRA                                            
305068,CARTAGO,TURRIALBA,HLE. SAN BUENAVENTURA                                  
305069,CARTAGO,TURRIALBA,MARGOT                                                 
305070,CARTAGO,TURRIALBA,CANADA                                                 
305071,CARTAGO,TURRIALBA,LAS VIRTUDES                                           
305072,CARTAGO,TURRIALBA,LAS NUBES                                              
305073,CARTAGO,TURRIALBA,QUETZAL                                                
305074,CARTAGO,TURRIALBA,PACUARE                                                
305075,CARTAGO,TURRIALBA,JAMO (SITIO HILDA PARTE OESTE)                         
305076,CARTAGO,TURRIALBA,ALTO PACUARE ABAJO (JEKUI)                             
305077,CARTAGO,TURRIALBA,JACBATA (CERRO AZUL)                                   
306001,CARTAGO,ALVARADO,PACAYAS                                                 
306002,CARTAGO,ALVARADO,IRAZU SUR                                               
306003,CARTAGO,ALVARADO,CERVANTES                                               
306004,CARTAGO,ALVARADO,CAPELLADES                                              
306005,CARTAGO,ALVARADO,BUENA VISTA                                             
306006,CARTAGO,ALVARADO,LLANO GRANDE                                            
306007,CARTAGO,ALVARADO,SAN RAFAEL DE IRAZU                                     
306008,CARTAGO,ALVARADO,SANTA TERESA                                            
306009,CARTAGO,ALVARADO,LOURDES (CALLEJON)                                      
307001,CARTAGO,OREAMUNO,SAN RAFAEL                                              
307002,CARTAGO,OREAMUNO,COT                                                     
307003,CARTAGO,OREAMUNO,PASO ANCHO                                              
307004,CARTAGO,OREAMUNO,POTRERO CERRADO                                         
307005,CARTAGO,OREAMUNO,SAN JUAN DE CHICUA                                      
307006,CARTAGO,OREAMUNO,CIPRESES                                                
307007,CARTAGO,OREAMUNO,SANTA ROSA                                              
307008,CARTAGO,OREAMUNO,SAN PABLO                                               
307009,CARTAGO,OREAMUNO,SAN GERARDO NORTE DEL IRAZU                             
307010,CARTAGO,OREAMUNO,SAN GERARDO SUR DE PASQUI                               
307011,CARTAGO,OREAMUNO,ALTO CERRILLOS(CORAZON DE JESUS)                        
307012,CARTAGO,OREAMUNO,BOSQUE                                                  
308001,CARTAGO,EL GUARCO,EL TEJAR                                               
308002,CARTAGO,EL GUARCO,SAN ISIDRO                                             
308003,CARTAGO,EL GUARCO,PALMITAL                                               
308004,CARTAGO,EL GUARCO,LA ESTRELLA                                            
308005,CARTAGO,EL GUARCO,TOBOSI                                                 
308006,CARTAGO,EL GUARCO,BARRIO NUEVO                                           
308007,CARTAGO,EL GUARCO,TABLON                                                 
308008,CARTAGO,EL GUARCO,PATIO DE AGUA                                          
308010,CARTAGO,EL GUARCO,CA�ON (PARTE NORTE)                                    
308011,CARTAGO,EL GUARCO,PURIRES (PARTE OESTE)                                  
308012,CARTAGO,EL GUARCO,CARAGRAL                                               
308013,CARTAGO,EL GUARCO,LA CANGREJA                                            
308014,CARTAGO,EL GUARCO,VARA DE ROBLE                                          
308015,CARTAGO,EL GUARCO,ASUNCION (CANGREJAL)                                   
308016,CARTAGO,EL GUARCO,SABANA GRANDE                                          
308017,CARTAGO,EL GUARCO,CAI. JORGE DEBRAVO                                     
401001,HEREDIA,CENTRAL,HEREDIA                                                  
401003,HEREDIA,CENTRAL,MERCEDES NORTE                                           
401004,HEREDIA,CENTRAL,MERCEDES SUR                                             
401005,HEREDIA,CENTRAL,SAN FRANCISCO                                            
401006,HEREDIA,CENTRAL,BARREAL (SAN JOSE)                                       
401007,HEREDIA,CENTRAL,VARABLANCA                                               
401008,HEREDIA,CENTRAL,LOS LAGOS                                                
401009,HEREDIA,CENTRAL,BERNARDO BENAVIDES (INVU)                                
401010,HEREDIA,CENTRAL,LA AURORA (PARTE SUR)                                    
401015,HEREDIA,CENTRAL,LAGUNILLA                                                
401016,HEREDIA,CENTRAL,SAN RAFAEL DE VARABLANCA                                 
401017,HEREDIA,CENTRAL,GUARARI                                                  
401018,HEREDIA,CENTRAL,LA AURORA (PARTE NORTE)                                  
402001,HEREDIA,BARVA,BARVA                                                      
402002,HEREDIA,BARVA,SAN PEDRO                                                  
402003,HEREDIA,BARVA,SAN JOSE DE LA MONTA�A                                     
402004,HEREDIA,BARVA,SAN PABLO                                                  
402005,HEREDIA,BARVA,SAN ROQUE                                                  
402006,HEREDIA,BARVA,SANTA LUCIA                                                
402007,HEREDIA,BARVA,SACRAMENTO                                                 
402008,HEREDIA,BARVA,PASO LLANO O PORROSATI                                     
402009,HEREDIA,BARVA,BUENAVISTA (ALTO DE ABRA)                                  
402010,HEREDIA,BARVA,PUENTE DE SALAS                                            
402011,HEREDIA,BARVA,SAN MIGUEL                                                 
402012,HEREDIA,BARVA,HLE. REINA DE LOS ANGELES                                  
403001,HEREDIA,SANTO DOMINGO,SANTO DOMINGO                                      
403002,HEREDIA,SANTO DOMINGO,SAN VICENTE                                        
403003,HEREDIA,SANTO DOMINGO,SAN MIGUEL                                         
403004,HEREDIA,SANTO DOMINGO,LOS ANGELES                                        
403005,HEREDIA,SANTO DOMINGO,SAN LUIS                                           
403006,HEREDIA,SANTO DOMINGO,PARACITO                                           
403007,HEREDIA,SANTO DOMINGO,SANTO TOMAS                                        
403008,HEREDIA,SANTO DOMINGO,SANTA ROSA                                         
403009,HEREDIA,SANTO DOMINGO,SOCORRO                                            
403012,HEREDIA,SANTO DOMINGO,CASTILLA (EL CARMEN)                               
404001,HEREDIA,SANTA BARBARA,SANTA BARBARA                                      
404002,HEREDIA,SANTA BARBARA,SAN PEDRO                                          
404003,HEREDIA,SANTA BARBARA,SAN JUAN ABAJO                                     
404004,HEREDIA,SANTA BARBARA,JESUS                                              
404005,HEREDIA,SANTA BARBARA,BIRRI                                              
404006,HEREDIA,SANTA BARBARA,SANTO DOMINGO DEL ROBLE                            
404007,HEREDIA,SANTA BARBARA,SETILLAL                                           
404008,HEREDIA,SANTA BARBARA,CHAGUITE                                           
404009,HEREDIA,SANTA BARBARA,LOS CARTAGOS                                       
404010,HEREDIA,SANTA BARBARA,SAN BOSCO                                          
405001,HEREDIA,SAN RAFAEL,SAN RAFAEL                                            
405002,HEREDIA,SAN RAFAEL,SAN JOSECITO                                          
405003,HEREDIA,SAN RAFAEL,SANTIAGO                                              
405004,HEREDIA,SAN RAFAEL,LOS ANGELES                                           
405005,HEREDIA,SAN RAFAEL,CONCEPCION                                            
405006,HEREDIA,SAN RAFAEL,GETSEMANI (PARTE ESTE)                                
405007,HEREDIA,SAN RAFAEL,MONTECITO                                             
405008,HEREDIA,SAN RAFAEL,LA SUIZA                                              
405009,HEREDIA,SAN RAFAEL,SAN MIGUEL O PALMAR (ESTE)                            
406001,HEREDIA,SAN ISIDRO,SAN ISIDRO                                            
406002,HEREDIA,SAN ISIDRO,SAN FRANCISCO                                         
406003,HEREDIA,SAN ISIDRO,SAN JOSECITO                                          
406004,HEREDIA,SAN ISIDRO,CONCEPCION                                            
406005,HEREDIA,SAN ISIDRO,SANTA ELENA                                           
406006,HEREDIA,SAN ISIDRO,SANTA CECILIA (ALHAJAS)                               
406007,HEREDIA,SAN ISIDRO,CENTRO DE FORMACION JUVENIL ZURQUI                    
406008,HEREDIA,SAN ISIDRO,HLE. SE�ORA DE LOS ANGELES                            
406009,HEREDIA,SAN ISIDRO,QUEBRADAS O LOURDES (PARTE NORTE)                     
407001,HEREDIA,BELEN,SAN ANTONIO                                                
407002,HEREDIA,BELEN,LA RIBERA                                                  
407003,HEREDIA,BELEN,LA ASUNCION                                                
408001,HEREDIA,FLORES,SAN JOAQUIN                                               
408002,HEREDIA,FLORES,SAN LORENZO                                               
408003,HEREDIA,FLORES,LLORENTE                                                  
409001,HEREDIA,SAN PABLO,SAN PABLO                                              
409002,HEREDIA,SAN PABLO,RINCON DE RICARDO                                      
409003,HEREDIA,SAN PABLO,MIRAFLORES                                             
409004,HEREDIA,SAN PABLO,HLE.ALFRED Y DELIA GONZALEZ FLORES                     
410001,HEREDIA,SARAPIQUI,PUERTO VIEJO                                           
410002,HEREDIA,SARAPIQUI,SAN JOSE DE RIO SARAPIQUI                              
410003,HEREDIA,SARAPIQUI,LA VIRGEN                                              
410004,HEREDIA,SARAPIQUI,PANGOLA O SAN JUAN                                     
410005,HEREDIA,SARAPIQUI, LLANO GRANDE                                          
410006,HEREDIA,SARAPIQUI,SAN RAMON                                              
410007,HEREDIA,SARAPIQUI,LOS ANGELES DE COLONIA CARVAJAL                        
410008,HEREDIA,SARAPIQUI,LA CEIBA                                               
410009,HEREDIA,SARAPIQUI,LAS HORQUETAS                                          
410010,HEREDIA,SARAPIQUI,RIO FRIO                                               
410011,HEREDIA,SARAPIQUI,EL TIGRE SUR                                           
410012,HEREDIA,SARAPIQUI,PUEBLO NUEVO                                           
410013,HEREDIA,SARAPIQUI,CHILAMATE ESTE ALTOS                                   
410014,HEREDIA,SARAPIQUI,SAN JULIAN                                             
410015,HEREDIA,SARAPIQUI,LA RAMBLA                                              
410016,HEREDIA,SARAPIQUI,FINCA DIEZ                                             
410017,HEREDIA,SARAPIQUI,LOS ARBOLITOS (PARTE ESTE)                             
410018,HEREDIA,SARAPIQUI,FINCA DOS                                              
410019,HEREDIA,SARAPIQUI,COLONIA CUBUJUQUI                                      
410020,HEREDIA,SARAPIQUI,CERRO NEGRO(PARTE SUR)                                 
410021,HEREDIA,SARAPIQUI,ZAPOTE                                                 
410022,HEREDIA,SARAPIQUI,COLONIA SAN JOSE                                       
410023,HEREDIA,SARAPIQUI,COLONIA VICTORIA                                       
410024,HEREDIA,SARAPIQUI,EL PALMAR                                              
410025,HEREDIA,SARAPIQUI,LAS MARIAS                                             
410026,HEREDIA,SARAPIQUI,GOLFITO                                                
410027,HEREDIA,SARAPIQUI,COLONIA VILLALOBOS                                     
410028,HEREDIA,SARAPIQUI,SAN BERNARDINO                                         
410029,HEREDIA,SARAPIQUI,ESTERO GRANDE                                          
410030,HEREDIA,SARAPIQUI,LA  CHAVES                                             
410031,HEREDIA,SARAPIQUI,EL ROBLE                                               
410032,HEREDIA,SARAPIQUI,TIRIMBINA                                              
410033,HEREDIA,SARAPIQUI,LA CONQUISTA                                           
410034,HEREDIA,SARAPIQUI,GUARIA                                                 
410035,HEREDIA,SARAPIQUI,FINCA CINCO (CHIRRIPO)                                 
410036,HEREDIA,SARAPIQUI,HUETARES                                               
410037,HEREDIA,SARAPIQUI,LA ALDEA                                               
410038,HEREDIA,SARAPIQUI,ANGELES DE RIO SARAPIQUI                               
410039,HEREDIA,SARAPIQUI,EL MORTERO                                             
410040,HEREDIA,SARAPIQUI,COLONIA LA GATA                                        
410041,HEREDIA,SARAPIQUI,NARANJAL                                               
410042,HEREDIA,SARAPIQUI,SANTA DELIA                                            
410043,HEREDIA,SARAPIQUI,FINCA AGUA                                             
410044,HEREDIA,SARAPIQUI,RANCHO CHILAMATE                                       
410045,HEREDIA,SARAPIQUI,HLE. SAN AGUSTIN                                       
410046,HEREDIA,SARAPIQUI,LAS PALMITAS                                           
501001,GUANACASTE,LIBERIA,LIBERIA                                               
501002,GUANACASTE,LIBERIA,GUARDIA                                               
501003,GUANACASTE,LIBERIA,CA�AS DULCES                                          
501004,GUANACASTE,LIBERIA,QUEBRADA GRANDE O GARCIA FLAMENCO                     
501005,GUANACASTE,LIBERIA,CURUBANDE                                             
501006,GUANACASTE,LIBERIA,BUENAVISTA DE CA�AS DULCES                            
501007,GUANACASTE,LIBERIA,IRIGARAY                                              
501008,GUANACASTE,LIBERIA,LAS LILAS                                             
501009,GUANACASTE,LIBERIA,CERECEDA (GUADALUPE)                                  
501010,GUANACASTE,LIBERIA,SALTO OESTE                                           
501011,GUANACASTE,LIBERIA,CAI. LIBERIA (MOD. B CASITAS)                         
501012,GUANACASTE,LIBERIA,HLE. LIBERIA                                          
501013,GUANACASTE,LIBERIA,BARRIO LA CRUZ                                        
501014,GUANACASTE,LIBERIA,CORAZON DE JESUS                                      
501015,GUANACASTE,LIBERIA,LA VICTORIA                                           
501016,GUANACASTE,LIBERIA,SAN ROQUE                                             
501017,GUANACASTE,LIBERIA,SANTA MARIA                                           
501019,GUANACASTE,LIBERIA,EL GALLO                                              
501020,GUANACASTE,LIBERIA,RODEITO                                               
501021,GUANACASTE,LIBERIA,MORACIA                                               
501022,GUANACASTE,LIBERIA,CAI. LIBERIA  (MODULO D1-D2)                          
501023,GUANACASTE,LIBERIA,CAPULIN                                               
501024,GUANACASTE,LIBERIA,CAI. LIBERIA  (MODULO D3-D4)                          
502001,GUANACASTE,NICOYA,NICOYA                                                 
502002,GUANACASTE,NICOYA,QUIRIMAN                                               
502003,GUANACASTE,NICOYA,SABANA GRANDE                                          
502004,GUANACASTE,NICOYA,JUAN DIAZ                                              
502005,GUANACASTE,NICOYA,SAN MARTIN                                             
502006,GUANACASTE,NICOYA,SAN JOAQUIN                                            
502007,GUANACASTE,NICOYA,DULCE NOMBRE (GARITA)                                  
502008,GUANACASTE,NICOYA,CAIMITAL                                               
502010,GUANACASTE,NICOYA,SAN FERNANDO                                           
502011,GUANACASTE,NICOYA,MAQUENCO                                               
502012,GUANACASTE,NICOYA,LA MANSION                                             
502013,GUANACASTE,NICOYA,MATINA                                                 
502014,GUANACASTE,NICOYA,CABALLITO                                              
502016,GUANACASTE,NICOYA,LA VIGIA                                               
502017,GUANACASTE,NICOYA,COPAL                                                  
502018,GUANACASTE,NICOYA,SANTA ELENA (PARTE OESTE)                              
502019,GUANACASTE,NICOYA,QUEBRADA HONDA                                         
502020,GUANACASTE,NICOYA,PUEBLO VIEJO                                           
502021,GUANACASTE,NICOYA,SANTA ANA                                              
502022,GUANACASTE,NICOYA,CERRO NEGRO                                            
502023,GUANACASTE,NICOYA,LA ESPERANZA NORTE O DE JUAN DIAZ                      
502026,GUANACASTE,NICOYA,NARANJAL                                               
502027,GUANACASTE,NICOYA,LA VIRGINIA DE GAMALOTAL                               
502028,GUANACASTE,NICOYA,EL JOBO NORTE                                          
502030,GUANACASTE,NICOYA,SAN ANTONIO                                            
502031,GUANACASTE,NICOYA,CORRALILLO                                             
502032,GUANACASTE,NICOYA,PUERTO HUMO                                            
502033,GUANACASTE,NICOYA,SAN LAZARO                                             
502034,GUANACASTE,NICOYA,SAN VICENTE ABAJO                                      
502035,GUANACASTE,NICOYA,ZAPOTE                                                 
502036,GUANACASTE,NICOYA,POZO DE AGUA                                           
502037,GUANACASTE,NICOYA,BOCAS DE NOSARA                                        
502039,GUANACASTE,NICOYA,EL ROBLAR                                              
502040,GUANACASTE,NICOYA,EL CA�AL                                               
502041,GUANACASTE,NICOYA,NAMBI                                                  
502042,GUANACASTE,NICOYA,CUAJINIQUIL                                            
502043,GUANACASTE,NICOYA,FLORIDA                                                
502044,GUANACASTE,NICOYA,MORACIA                                                
502045,GUANACASTE,NICOYA,RIO MONTA�A                                            
502047,GUANACASTE,NICOYA,TERCIOPELO                                             
502049,GUANACASTE,NICOYA,TALOLINGA                                              
502051,GUANACASTE,NICOYA,CURIME                                                 
502052,GUANACASTE,NICOYA,BELEN DE NOSARITA                                      
502053,GUANACASTE,NICOYA,CUESTA GRANDE                                          
502056,GUANACASTE,NICOYA,MONTE GALAN                                            
502057,GUANACASTE,NICOYA,EL ROSARIO                                             
502058,GUANACASTE,NICOYA,GARZA                                                  
502059,GUANACASTE,NICOYA,IGUANITA                                               
502060,GUANACASTE,NICOYA,SAMARA                                                 
502061,GUANACASTE,NICOYA,BARCO QUEBRADO                                         
502062,GUANACASTE,NICOYA,BARRAHONDA O NACAOME                                   
502064,GUANACASTE,NICOYA,SILENCIO                                               
502065,GUANACASTE,NICOYA,PILAS BLANCAS                                          
502066,GUANACASTE,NICOYA,CONCEPCION DE PLATANILLO                               
502067,GUANACASTE,NICOYA,SANTO DOMINGO                                          
502071,GUANACASTE,NICOYA,SAN JUAN (PARTE NORTE)                                 
502072,GUANACASTE,NICOYA,LOMA BONITA O LAS CASITAS                              
502073,GUANACASTE,NICOYA,GAMALOTAL                                              
502074,GUANACASTE,NICOYA,JUNTAS                                                 
502076,GUANACASTE,NICOYA,LA ESPERANZA SUR                                       
502077,GUANACASTE,NICOYA,DELICIAS DE GARZA                                      
502079,GUANACASTE,NICOYA,EL FLOR (ROJAS)                                        
502080,GUANACASTE,NICOYA,MATAMBUGUITO                                           
502081,GUANACASTE,NICOYA,CASITAS                                                
502082,GUANACASTE,NICOYA,GARCIMU�OZ                                             
502083,GUANACASTE,NICOYA,ACOYAPA                                                
502084,GUANACASTE,NICOYA,HLE. SAN BLAS                                          
502085,GUANACASTE,NICOYA,MONTA�ITA                                              
502086,GUANACASTE,NICOYA,RIO GRANDE                                             
503001,GUANACASTE,SANTA CRUZ,SANTA CRUZ                                         
503002,GUANACASTE,SANTA CRUZ,ARADO                                              
503003,GUANACASTE,SANTA CRUZ,LAGUNILLA                                          
503004,GUANACASTE,SANTA CRUZ,SAN JUAN                                           
503005,GUANACASTE,SANTA CRUZ,BERNABELA                                          
503006,GUANACASTE,SANTA CRUZ,CACAO                                              
503007,GUANACASTE,SANTA CRUZ,BOLSON                                             
503008,GUANACASTE,SANTA CRUZ,SANTA BARBARA                                      
503009,GUANACASTE,SANTA CRUZ,PARAISO O RIO SEQUITO                              
503010,GUANACASTE,SANTA CRUZ,VEINTISIETE DE ABRIL                               
503011,GUANACASTE,SANTA CRUZ,RIO SECO                                           
503012,GUANACASTE,SANTA CRUZ,MARBELLA                                           
503013,GUANACASTE,SANTA CRUZ,VILLARREAL                                         
503014,GUANACASTE,SANTA CRUZ,SANTA ROSA                                         
503015,GUANACASTE,SANTA CRUZ,SAN FRANCISCO                                      
503016,GUANACASTE,SANTA CRUZ,SAN JOSE DE PINILLA                                
503017,GUANACASTE,SANTA CRUZ,HATILLO                                            
503018,GUANACASTE,SANTA CRUZ,TEMPATE                                            
503019,GUANACASTE,SANTA CRUZ,CARTAGENA                                          
503020,GUANACASTE,SANTA CRUZ,PORTEGOLPE                                         
503021,GUANACASTE,SANTA CRUZ,HUACAS                                             
503022,GUANACASTE,SANTA CRUZ,MATAPALO                                           
503023,GUANACASTE,SANTA CRUZ,FLORIDA                                            
503024,GUANACASTE,SANTA CRUZ,DIRIA O RIO GRANDE                                 
503025,GUANACASTE,SANTA CRUZ,SAN JUANILLO                                       
503026,GUANACASTE,SANTA CRUZ,VISTAMAR (CENIZOSA)                                
503027,GUANACASTE,SANTA CRUZ,POTRERO                                            
503028,GUANACASTE,SANTA CRUZ,OSTIONAL                                           
503029,GUANACASTE,SANTA CRUZ,SAN JOSE DE LA MONTA�A                             
503030,GUANACASTE,SANTA CRUZ,EL SOCORRO                                         
503031,GUANACASTE,SANTA CRUZ,PALMARES                                           
503032,GUANACASTE,SANTA CRUZ,LORENA                                             
503033,GUANACASTE,SANTA CRUZ,RIO TABACO ARRIBA                                  
503034,GUANACASTE,SANTA CRUZ,JAZMINAL                                           
503035,GUANACASTE,SANTA CRUZ,BRASILITO                                          
503037,GUANACASTE,SANTA CRUZ,DELICIAS                                           
503038,GUANACASTE,SANTA CRUZ,GARITA NUEVA                                       
503039,GUANACASTE,SANTA CRUZ,LIMON                                              
503040,GUANACASTE,SANTA CRUZ,EL LLANO (EL CHORRO)                               
503041,GUANACASTE,SANTA CRUZ,ORTEGA                                             
503042,GUANACASTE,SANTA CRUZ,TALOLINGUITA                                       
503043,GUANACASTE,SANTA CRUZ,SAN PEDRO                                          
503044,GUANACASTE,SANTA CRUZ,GUAITIL                                            
503045,GUANACASTE,SANTA CRUZ,HLE. NUESTRA SE�ORA DEL ROSARIO                    
503046,GUANACASTE,SANTA CRUZ,CHIRCO                                             
504001,GUANACASTE,BAGACES,BAGACES                                               
504002,GUANACASTE,BAGACES,MONTANO                                               
504003,GUANACASTE,BAGACES,BEBEDERO (NORTE DEL RIO)                              
504004,GUANACASTE,BAGACES,RIO NARANJO                                           
504005,GUANACASTE,BAGACES,CUIPILAPA                                             
504006,GUANACASTE,BAGACES,LA FORTUNA                                            
504008,GUANACASTE,BAGACES,GUAYABO                                               
504009,GUANACASTE,BAGACES,SALITRAL                                              
504010,GUANACASTE,BAGACES,SAN BERNARDO                                          
504011,GUANACASTE,BAGACES,MONTENEGRO                                            
504013,GUANACASTE,BAGACES,PUEBLO NUEVO                                          
504014,GUANACASTE,BAGACES,PIJIJE                                                
504016,GUANACASTE,BAGACES,RIO CHIQUITO                                          
504017,GUANACASTE,BAGACES,SAN ISIDRO DE LIMONAL                                 
504018,GUANACASTE,BAGACES,BAGATZI                                               
504019,GUANACASTE,BAGACES,LLANOS DE CORTES                                      
504020,GUANACASTE,BAGACES,AGUA CALIENTE                                         
505001,GUANACASTE,CARRILLO,FILADELFIA                                           
505002,GUANACASTE,CARRILLO,PALMIRA                                              
505003,GUANACASTE,CARRILLO,COMUNIDAD                                            
505004,GUANACASTE,CARRILLO,SARDINAL                                             
505005,GUANACASTE,CARRILLO,SAN BLAS                                             
505006,GUANACASTE,CARRILLO,ARTOLA                                               
505007,GUANACASTE,CARRILLO,BELEN                                                
505008,GUANACASTE,CARRILLO,SANTA ANA                                            
505009,GUANACASTE,CARRILLO,SANTO DOMINGO                                        
505010,GUANACASTE,CARRILLO,LOS PLANES                                           
505011,GUANACASTE,CARRILLO,EL COCO                                              
505012,GUANACASTE,CARRILLO,RIO CA�AS NUEVO                                      
505013,GUANACASTE,CARRILLO,LA GUINEA                                            
505014,GUANACASTE,CARRILLO,CORRALILLO                                           
505015,GUANACASTE,CARRILLO,PANAMA O CACIQUE                                     
505016,GUANACASTE,CARRILLO,CASTILLA DE ORO                                      
505017,GUANACASTE,CARRILLO,COYOLITO                                             
505018,GUANACASTE,CARRILLO,NUEVO COLON                                          
505019,GUANACASTE,CARRILLO,SANTA RITA                                           
505020,GUANACASTE,CARRILLO,LIBERTAD (HUACAS)                                    
505021,GUANACASTE,CARRILLO,PASO TEMPISQUE (PARTE OESTE)                         
505022,GUANACASTE,CARRILLO,ALTOS DEL ROBLE                                      
506001,GUANACASTE,CA�AS,CA�AS                                                   
506002,GUANACASTE,CA�AS,HIGUERON ABAJO                                          
506003,GUANACASTE,CA�AS,PALMIRA                                                 
506004,GUANACASTE,CA�AS,BEBEDERO (SUR DEL RIO)                                  
506005,GUANACASTE,CA�AS,POROZAL                                                 
506006,GUANACASTE,CA�AS,NUEVA GUATEMALA                                         
506007,GUANACASTE,CA�AS,SAN MIGUEL O CUATRO ESQUINAS                            
506008,GUANACASTE,CA�AS,NISPERO (PUERTO ALEGRE)                                 
506009,GUANACASTE,CA�AS,BUENOS AIRES LA GOTERA(ALTO LAJAS)                      
506010,GUANACASTE,CA�AS,HOTEL                                                   
506011,GUANACASTE,CA�AS,SANDILLAL                                               
506012,GUANACASTE,CA�AS,EL VERGEL                                               
506013,GUANACASTE,CA�AS,SAN JUAN                                                
506014,GUANACASTE,CA�AS,JABILLA ABAJO                                           
506015,GUANACASTE,CA�AS,SAN MARTIN                                              
506016,GUANACASTE,CA�AS,LAS PALMAS                                              
506017,GUANACASTE,CA�AS,HLE.  MARY BLANCO                                       
506018,GUANACASTE,CA�AS,URB. LAS CA�AS                                          
507001,GUANACASTE,ABANGARES,LAS JUNTAS                                          
507002,GUANACASTE,ABANGARES,SANTA LUCIA                                         
507003,GUANACASTE,ABANGARES,LA SIERRA (LAS MINAS)                               
507004,GUANACASTE,ABANGARES,ALTO CEBADILLA                                      
507005,GUANACASTE,ABANGARES,LA PALMA                                            
507006,GUANACASTE,ABANGARES,EL DOS DE ABANGARES (BAJO CHARIO)                   
507007,GUANACASTE,ABANGARES,SAN JUAN GRANDE                                     
507008,GUANACASTE,ABANGARES,POZO AZUL                                           
507009,GUANACASTE,ABANGARES,COLORADO                                            
507010,GUANACASTE,ABANGARES,SAN BUENAVENTURA                                    
507011,GUANACASTE,ABANGARES,SAN JOAQUIN                                         
507012,GUANACASTE,ABANGARES,MONTE POTRERO O PUEBLO NUEVO                        
507013,GUANACASTE,ABANGARES,CAMPOS DE ORO DE ABANGARES                          
507014,GUANACASTE,ABANGARES,SAN RAFAEL (DESPACIO)                               
507015,GUANACASTE,ABANGARES,LOS ANGELES (PORTONES)                              
507016,GUANACASTE,ABANGARES,HIGUERILLAS                                         
507017,GUANACASTE,ABANGARES,MATAPALO                                            
507018,GUANACASTE,ABANGARES,BARRIO JESUS                                        
507019,GUANACASTE,ABANGARES,RANCHO ANIA O LOURDES (PN)                          
507020,GUANACASTE,ABANGARES,CA�ITAS                                             
507021,GUANACASTE,ABANGARES,COYOLITO DE ABANGARES O LA PE�A                     
507022,GUANACASTE,ABANGARES,TORNOS                                              
507023,GUANACASTE,ABANGARES,HLE. SAN JORGE                                      
507024,GUANACASTE,ABANGARES,RAIZAL                                              
507025,GUANACASTE,ABANGARES,LA CONCHA (CONCEPCION)                              
507026,GUANACASTE,ABANGARES,PE�AS BLANCAS                                       
508001,GUANACASTE,TILARAN,TILARAN                                               
508002,GUANACASTE,TILARAN,QUEBRADA GRANDE                                       
508003,GUANACASTE,TILARAN,SAN RAMON                                             
508004,GUANACASTE,TILARAN,CABECERAS DE CA�AS                                    
508005,GUANACASTE,TILARAN,TRONADORA                                             
508006,GUANACASTE,TILARAN,AGUACATE (PARTE OESTE)                                
508007,GUANACASTE,TILARAN,LOS ANGELES (SANTA ROSA)                              
508008,GUANACASTE,TILARAN,PARCE. QUEBRADA AZUL (LINDA VISTA)                    
508009,GUANACASTE,TILARAN,LIBANO                                                
508010,GUANACASTE,TILARAN,SAN JOSE                                              
508011,GUANACASTE,TILARAN,TIERRAS MORENAS                                       
508012,GUANACASTE,TILARAN,FLORIDA (PATIOS)                                      
508013,GUANACASTE,TILARAN,SAN MIGUEL                                            
508014,GUANACASTE,TILARAN,ARENAL NUEVO                                          
508015,GUANACASTE,TILARAN,SOLANIA                                               
508016,GUANACASTE,TILARAN,LAS NUBES DE RIO CHIQUITO                             
508017,GUANACASTE,TILARAN,RIO CHIQUITO                                          
508018,GUANACASTE,TILARAN,LA UNION                                              
508019,GUANACASTE,TILARAN,RIO PIEDRAS (GUADALAJARA)                             
508021,GUANACASTE,TILARAN,VIEJO ARENAL                                          
508022,GUANACASTE,TILARAN,SILENCIO                                              
508023,GUANACASTE,TILARAN,SAN LUIS                                              
508024,GUANACASTE,TILARAN,HLE. TILARAN                                          
509001,GUANACASTE,NANDAYURE,CARMONA                                             
509002,GUANACASTE,NANDAYURE,SANTA RITA                                          
509003,GUANACASTE,NANDAYURE,SAN ANTONIO DE ZAPOTAL                              
509004,GUANACASTE,NANDAYURE,SAN PABLO                                           
509005,GUANACASTE,NANDAYURE,BELLAVISTA                                          
509006,GUANACASTE,NANDAYURE,BEJUCO                                              
509007,GUANACASTE,NANDAYURE,QUEBRADA SECA O PILAS DE BEJUCO                     
509008,GUANACASTE,NANDAYURE,SAN PEDRO                                           
509009,GUANACASTE,NANDAYURE,EL CARMEN                                           
509010,GUANACASTE,NANDAYURE,CERRO AZUL                                          
509011,GUANACASTE,NANDAYURE,LOS ANGELES                                         
509012,GUANACASTE,NANDAYURE,COROZALITO                                          
509013,GUANACASTE,NANDAYURE,SAN FRANCISCO DE COYOTE                             
509014,GUANACASTE,NANDAYURE,JABILLOS                                            
509016,GUANACASTE,NANDAYURE,TACANIS                                             
509017,GUANACASTE,NANDAYURE,SAN RAMON                                           
509018,GUANACASTE,NANDAYURE,PAVONES                                             
509019,GUANACASTE,NANDAYURE,QUEBRADA NANDO                                      
509020,GUANACASTE,NANDAYURE,QUEBRADA GRANDE                                     
509021,GUANACASTE,NANDAYURE,ZAPOTE O MORAVIA                                    
509023,GUANACASTE,NANDAYURE,COLONIA DEL VALLE                                   
509024,GUANACASTE,NANDAYURE,CACAO                                               
509025,GUANACASTE,NANDAYURE,RIO DE ORO                                          
509026,GUANACASTE,NANDAYURE,JABILLA                                             
509027,GUANACASTE,NANDAYURE,HLE. SAGRADO CORAZON DE JESUS                       
510001,GUANACASTE,LA CRUZ,LA CRUZ                                               
510002,GUANACASTE,LA CRUZ,COPALCHI                                              
510003,GUANACASTE,LA CRUZ,TEMPATAL                                              
510004,GUANACASTE,LA CRUZ,SANTA CECILIA                                         
510005,GUANACASTE,LA CRUZ,LA GARITA                                             
510006,GUANACASTE,LA CRUZ,CUAJINIQUIL DE SANTA ELENA                            
510007,GUANACASTE,LA CRUZ,ARMENIA                                               
510008,GUANACASTE,LA CRUZ,GUAPINOL                                              
510009,GUANACASTE,LA CRUZ,LAS BRISAS                                            
510010,GUANACASTE,LA CRUZ,LA VIRGEN                                             
510011,GUANACASTE,LA CRUZ,EL PORVENIR (SANTA ROGELIA)                           
510015,GUANACASTE,LA CRUZ,JOBO (COLONIA GIL TABLADA)                            
510016,GUANACASTE,LA CRUZ,LOS ANDES                                             
510017,GUANACASTE,LA CRUZ,LAS VUELTAS                                           
510018,GUANACASTE,LA CRUZ,CAOBA                                                 
510019,GUANACASTE,LA CRUZ,BELICE                                                
510020,GUANACASTE,LA CRUZ,PALMARES                                              
510021,GUANACASTE,LA CRUZ,PIEDRAS AZULES                                        
510022,GUANACASTE,LA CRUZ,SANTA ELENA                                           
510023,GUANACASTE,LA CRUZ,SONZAPOTE                                             
510024,GUANACASTE,LA CRUZ,SAN FERNANDO                                          
511001,GUANACASTE,HOJANCHA,HOJANCHA                                             
511003,GUANACASTE,HOJANCHA,LA MARAVILLA                                         
511004,GUANACASTE,HOJANCHA,PILANGOSTA                                           
511005,GUANACASTE,HOJANCHA,LAJAS                                                
511006,GUANACASTE,HOJANCHA,BETANIA O JOBO                                       
511007,GUANACASTE,HOJANCHA,CUESTA ROJA                                          
511009,GUANACASTE,HOJANCHA,MONTE ROMO                                           
511010,GUANACASTE,HOJANCHA,ARBOLITOS (SANTA MARTA)                              
511011,GUANACASTE,HOJANCHA,MATAMBU                                              
511012,GUANACASTE,HOJANCHA,PITA RAYADA                                          
511013,GUANACASTE,HOJANCHA,HUACAS                                               
511016,GUANACASTE,HOJANCHA,ESTRADA                                              
511017,GUANACASTE,HOJANCHA,PUERTO CARRILLO                                      
511018,GUANACASTE,HOJANCHA,LOS ANGELES NORTE                                    
511019,GUANACASTE,HOJANCHA,ALTOS DEL SOCORRO                                    
601001,PUNTARENAS,CENTRAL,PUNTARENAS                                            
601004,PUNTARENAS,CENTRAL,PITAHAYA                                              
601005,PUNTARENAS,CENTRAL,SARDINAL DE ACAPULCO                                  
601006,PUNTARENAS,CENTRAL,CHOMES                                                
601007,PUNTARENAS,CENTRAL,SARMIENTO                                             
601008,PUNTARENAS,CENTRAL,LAGARTO SUR                                           
601009,PUNTARENAS,CENTRAL,LEPANTO                                               
601010,PUNTARENAS,CENTRAL,MONTA�A GRANDE                                        
601011,PUNTARENAS,CENTRAL,JICARAL                                               
601012,PUNTARENAS,CENTRAL,PAQUERA                                               
601013,PUNTARENAS,CENTRAL,TAMBOR                                                
601014,PUNTARENAS,CENTRAL,MANZANILLO DEL GOLFO                                  
601016,PUNTARENAS,CENTRAL,NANCITE (SAN ANTONIO)                                 
601017,PUNTARENAS,CENTRAL,BARRANCA                                              
601018,PUNTARENAS,CENTRAL,SAN MIGUEL DE BARRANCA                                
601019,PUNTARENAS,CENTRAL,COROZAL                                               
601020,PUNTARENAS,CENTRAL,VAINILLA                                              
601021,PUNTARENAS,CENTRAL,JUAN DE LEON                                          
601022,PUNTARENAS,CENTRAL,CUAJINIQUIL                                           
601023,PUNTARENAS,CENTRAL,GUACIMAL                                              
601024,PUNTARENAS,CENTRAL,COBANO                                                
601026,PUNTARENAS,CENTRAL,DOMINICAS                                             
601027,PUNTARENAS,CENTRAL,MONTEZUMA                                             
601028,PUNTARENAS,CENTRAL,PILAS DE CANJEL                                       
601030,PUNTARENAS,CENTRAL,SAN RAMON DE RIO BLANCO                               
601031,PUNTARENAS,CENTRAL,COSTA DE PAJAROS(BRISAS DEL GOLFO)                    
601032,PUNTARENAS,CENTRAL,SANTA ROSA                                            
601033,PUNTARENAS,CENTRAL,CABO BLANCO DEL GOLFO                                 
601034,PUNTARENAS,CENTRAL,CARMEN LIRA                                           
601035,PUNTARENAS,CENTRAL,POCHOTE                                               
601036,PUNTARENAS,CENTRAL,RIO NEGRO                                             
601037,PUNTARENAS,CENTRAL,BELLO HORIZONTE                                       
601038,PUNTARENAS,CENTRAL,LA ESPERANZA                                          
601039,PUNTARENAS,CENTRAL,RIO FRIO                                              
601040,PUNTARENAS,CENTRAL,ABANGARITOS                                           
601041,PUNTARENAS,CENTRAL,FLORIDA (TACOTALES)                                   
601042,PUNTARENAS,CENTRAL,LA TIGRA (BELLAVISTA)                                 
601043,PUNTARENAS,CENTRAL,KENNEDY (INVU BARRANCA)                               
601044,PUNTARENAS,CENTRAL,RIO GRANDE                                            
601045,PUNTARENAS,CENTRAL,SAN RAFAEL                                            
601046,PUNTARENAS,CENTRAL,GUARIA                                                
601047,PUNTARENAS,CENTRAL,CHACARITA                                             
601048,PUNTARENAS,CENTRAL,SAN MIGUEL DE RIO BLANCO                              
601049,PUNTARENAS,CENTRAL,EL BALSO                                              
601050,PUNTARENAS,CENTRAL,SAN BLAS                                              
601052,PUNTARENAS,CENTRAL,PAVON                                                 
601054,PUNTARENAS,CENTRAL,SAN RAFAEL DE ACAPULCO                                
601055,PUNTARENAS,CENTRAL,OJO DE AGUA                                           
601056,PUNTARENAS,CENTRAL,BAJO CALIENTE (PARTE OESTE)                           
601057,PUNTARENAS,CENTRAL,ISLA CABALLO                                          
601058,PUNTARENAS,CENTRAL,MALINCHE                                              
601059,PUNTARENAS,CENTRAL,JUDAS                                                 
601064,PUNTARENAS,CENTRAL,GIGANTE                                               
601065,PUNTARENAS,CENTRAL,PUEBLO NUEVO                                          
601067,PUNTARENAS,CENTRAL,CABUYA                                                
601068,PUNTARENAS,CENTRAL,MAL PAIS                                              
601069,PUNTARENAS,CENTRAL,COYOLITO (OESTE)                                      
601072,PUNTARENAS,CENTRAL,ARANJUEZ                                              
601074,PUNTARENAS,CENTRAL,ORIENTE (ISLA VENADO PARTE)                           
601077,PUNTARENAS,CENTRAL,CORAZON DE JESUS (ARANCIBIA NORTE)                    
601081,PUNTARENAS,CENTRAL,CHAPERNAL                                             
601082,PUNTARENAS,CENTRAL,LA FRESCA                                             
601083,PUNTARENAS,CENTRAL,BAJO NEGRO                                            
601085,PUNTARENAS,CENTRAL,MORALES                                               
601086,PUNTARENAS,CENTRAL,EL ROBLE                                              
601087,PUNTARENAS,CENTRAL,FRAY CASIANO DE MADRID                                
601088,PUNTARENAS,CENTRAL,BARRIO EL CARMEN                                      
601089,PUNTARENAS,CENTRAL,EL COCAL                                              
601090,PUNTARENAS,CENTRAL,BOCANA                                                
601091,PUNTARENAS,CENTRAL,SAN PEDRO                                             
601092,PUNTARENAS,CENTRAL,CEBADILLA DE ARANJUEZ (BRILLANTE)                     
601093,PUNTARENAS,CENTRAL,PANICA                                                
601094,PUNTARENAS,CENTRAL,CAI. 26 DE JULIO (M. SENTENCIADOS)                    
601095,PUNTARENAS,CENTRAL,PUERTO PALITO                                         
601096,PUNTARENAS,CENTRAL,FLORIDA(ISLA VENADO PARTE)                            
601097,PUNTARENAS,CENTRAL,CONCEPCION                                            
601098,PUNTARENAS,CENTRAL,JUANITO MORA                                          
601100,PUNTARENAS,CENTRAL,EL PROGRESO                                           
601101,PUNTARENAS,CENTRAL,CHAGUITE                                              
601102,PUNTARENAS,CENTRAL,VALLE AZUL                                            
601103,PUNTARENAS,CENTRAL,HLE. MIGUEL MORENO                                    
601104,PUNTARENAS,CENTRAL,PLAYA BLANCA                                          
601105,PUNTARENAS,CENTRAL,ISLA DEL COCO                                         
601106,PUNTARENAS,CENTRAL,HLE. MARIA INMACULADA                                 
601107,PUNTARENAS,CENTRAL,YIRETH                                                
601108,PUNTARENAS,CENTRAL,SANTA TERESA (CARMEN)                                 
601109,PUNTARENAS,CENTRAL,CAI. 26 DE JULIO (MOD. INDICIADOS)                    
602001,PUNTARENAS,ESPARZA,ESPARZA                                               
602002,PUNTARENAS,ESPARZA,ARTIEDA (CHUMICAL)                                    
602003,PUNTARENAS,ESPARZA,SAN JUAN GRANDE                                       
602004,PUNTARENAS,ESPARZA,MATA DE LIMON                                         
602005,PUNTARENAS,ESPARZA,JUANILAMA                                             
602006,PUNTARENAS,ESPARZA,SALINAS                                               
602007,PUNTARENAS,ESPARZA,MACACONA                                              
602008,PUNTARENAS,ESPARZA,PE�A BLANCA                                           
602009,PUNTARENAS,ESPARZA,MESETAS ABAJO                                         
602010,PUNTARENAS,ESPARZA,SAN RAFAEL                                            
602011,PUNTARENAS,ESPARZA,GUADALUPE O MARATON                                   
602012,PUNTARENAS,ESPARZA,EL BARON                                              
602013,PUNTARENAS,ESPARZA,MOJON                                                 
602014,PUNTARENAS,ESPARZA,SAN JERONIMO                                          
602015,PUNTARENAS,ESPARZA,CERRILLOS                                             
602016,PUNTARENAS,ESPARZA,MARA�ONAL (PARTE OESTE)                               
602017,PUNTARENAS,ESPARZA,PARAISO O BRUSELAS                                    
602018,PUNTARENAS,ESPARZA,HLE. CARLOS VENEGAS                                   
602019,PUNTARENAS,ESPARZA,TIVIVES                                               
603001,PUNTARENAS,BUENOS AIRES,BUENOS AIRES                                     
603002,PUNTARENAS,BUENOS AIRES,SAN LUIS (FLORIDA)                               
603003,PUNTARENAS,BUENOS AIRES,SALITRE                                          
603004,PUNTARENAS,BUENOS AIRES,VOLCAN                                           
603005,PUNTARENAS,BUENOS AIRES,POTRERO GRANDE                                   
603006,PUNTARENAS,BUENOS AIRES,BORUCA                                           
603007,PUNTARENAS,BUENOS AIRES,LAS PILAS                                        
603008,PUNTARENAS,BUENOS AIRES,COLINAS (MAIZ DE LOS UVA)                        
603010,PUNTARENAS,BUENOS AIRES,JABILLO                                          
603011,PUNTARENAS,BUENOS AIRES,CURRE (REY CURRE)                                
603012,PUNTARENAS,BUENOS AIRES,LA DANTA O CONCEPCION                            
603013,PUNTARENAS,BUENOS AIRES,SAN RAFAEL DE BRUNKA                             
603014,PUNTARENAS,BUENOS AIRES,UJARRAS                                          
603015,PUNTARENAS,BUENOS AIRES,VUELTAS                                          
603016,PUNTARENAS,BUENOS AIRES,SANTA MARTA                                      
603017,PUNTARENAS,BUENOS AIRES,LA LUCHA                                         
603018,PUNTARENAS,BUENOS AIRES,PARAISO (ANIMAS)                                 
603019,PUNTARENAS,BUENOS AIRES,BAJO LAS BRISAS                                  
603020,PUNTARENAS,BUENOS AIRES,EL PEJE                                          
603021,PUNTARENAS,BUENOS AIRES,CORDONCILLO                                      
603022,PUNTARENAS,BUENOS AIRES,TERRABA                                          
603023,PUNTARENAS,BUENOS AIRES,SAN RAFAEL DE CABAGRA                            
603024,PUNTARENAS,BUENOS AIRES,PASO REAL                                        
603025,PUNTARENAS,BUENOS AIRES,BOLAS DE KRUGRA                                  
603026,PUNTARENAS,BUENOS AIRES,NARANJOS                                         
603027,PUNTARENAS,BUENOS AIRES,BIJAGUAL                                         
603028,PUNTARENAS,BUENOS AIRES,CAJON                                            
603029,PUNTARENAS,BUENOS AIRES,GUAGARAL                                         
603030,PUNTARENAS,BUENOS AIRES,MAIZ DE BORUCA                                   
603031,PUNTARENAS,BUENOS AIRES,CHANGUENA (LA FILA)                              
603032,PUNTARENAS,BUENOS AIRES,PILON                                            
603033,PUNTARENAS,BUENOS AIRES,LAS VEGAS DE RIO CHANGUENA                       
603034,PUNTARENAS,BUENOS AIRES,LA BONGA                                         
603035,PUNTARENAS,BUENOS AIRES,SAN VICENTE UPIAV-2                              
603036,PUNTARENAS,BUENOS AIRES,PARAISO                                          
603037,PUNTARENAS,BUENOS AIRES,SAN LUIS DE RIO LIMON                            
603038,PUNTARENAS,BUENOS AIRES,OLAN                                             
603039,PUNTARENAS,BUENOS AIRES,CACIQUE                                          
603040,PUNTARENAS,BUENOS AIRES,CAPRI                                            
603041,PUNTARENAS,BUENOS AIRES,PUENTE DE SALITRE                                
603042,PUNTARENAS,BUENOS AIRES,SAN ANTONIO                                      
603043,PUNTARENAS,BUENOS AIRES,VILLA HERMOSA                                    
603044,PUNTARENAS,BUENOS AIRES,EL CEIBO                                         
603045,PUNTARENAS,BUENOS AIRES,LA PUNA                                          
603046,PUNTARENAS,BUENOS AIRES,COLORADO                                         
603047,PUNTARENAS,BUENOS AIRES,EL CARMEN                                        
603048,PUNTARENAS,BUENOS AIRES,CONVENTO                                         
603049,PUNTARENAS,BUENOS AIRES,CA�AS                                            
603050,PUNTARENAS,BUENOS AIRES,SAN CARLOS                                       
603051,PUNTARENAS,BUENOS AIRES,SHAMBA                                           
603052,PUNTARENAS,BUENOS AIRES,CA�O BRAVO                                       
603053,PUNTARENAS,BUENOS AIRES,SANTA CRUZ                                       
603054,PUNTARENAS,BUENOS AIRES,PALMITAL                                         
604001,PUNTARENAS,MONTES DE ORO,MIRAMAR                                         
604002,PUNTARENAS,MONTES DE ORO,ZAGALA VIEJA                                    
604003,PUNTARENAS,MONTES DE ORO,RIO SECO                                        
604004,PUNTARENAS,MONTES DE ORO,LA UNION                                        
604005,PUNTARENAS,MONTES DE ORO,PALMITAL                                        
604006,PUNTARENAS,MONTES DE ORO,CEDRAL                                          
604007,PUNTARENAS,MONTES DE ORO,CIRUELAS                                        
604008,PUNTARENAS,MONTES DE ORO,SAN ISIDRO (TIGRE)                              
604009,PUNTARENAS,MONTES DE ORO,TAJO ALTO (PARTE SUR)                           
604012,PUNTARENAS,MONTES DE ORO,SANTA ROSA                                      
604013,PUNTARENAS,MONTES DE ORO,LAGUNA                                          
604014,PUNTARENAS,MONTES DE ORO,HLE. FRAY CASIANO DE MADRID                     
604015,PUNTARENAS,MONTES DE ORO,LINDA VISTA                                     
605001,PUNTARENAS,OSA,PUERTO CORTES                                             
605002,PUNTARENAS,OSA,PALMAR NORTE                                              
605003,PUNTARENAS,OSA,SIERPE                                                    
605004,PUNTARENAS,OSA,PIEDRAS BLANCAS                                           
605005,PUNTARENAS,OSA,PALMAR SUR                                                
605006,PUNTARENAS,OSA,OLLA CERO O SANTA EDUVIGIS                                
605007,PUNTARENAS,OSA,SAN FRANCISCO DE RIO TINOCO                               
605008,PUNTARENAS,OSA,GUARIA                                                    
605009,PUNTARENAS,OSA,CORONADO                                                  
605010,PUNTARENAS,OSA,OJOCHAL                                                   
605011,PUNTARENAS,OSA,DOMINICALITO                                              
605012,PUNTARENAS,OSA,MOGOS                                                     
605013,PUNTARENAS,OSA,UVITA                                                     
605015,PUNTARENAS,OSA,SAN BUENAVENTURA                                          
605016,PUNTARENAS,OSA,DRAKE (AGUJITAS)                                          
605017,PUNTARENAS,OSA,SABALO                                                    
605018,PUNTARENAS,OSA,LA NAVIDAD                                                
605020,PUNTARENAS,OSA,OJO DE AGUA                                               
605021,PUNTARENAS,OSA,VENECIA                                                   
605022,PUNTARENAS,OSA,RINCON DEL GOLFO                                          
605023,PUNTARENAS,OSA,CHOCUACO ARRIBA                                           
605024,PUNTARENAS,OSA,FINCA SEIS-ONCE                                           
605025,PUNTARENAS,OSA,BALSAR ARRIBA                                             
605026,PUNTARENAS,OSA,FINCA DOS-CUATRO                                          
605027,PUNTARENAS,OSA,RIYITO DE SIERPE                                          
605028,PUNTARENAS,OSA,MIRAMAR                                                   
605030,PUNTARENAS,OSA,JALACA (PARTE SUR)                                        
605032,PUNTARENAS,OSA,SINAI                                                     
605033,PUNTARENAS,OSA,RANCHO QUEMADO O DELICIAS                                 
605034,PUNTARENAS,OSA,CA�ABLANCAL                                               
605035,PUNTARENAS,OSA,EL PROGRESO                                               
605036,PUNTARENAS,OSA,FINCA GUANACASTE (PARTE OESTE)                            
605037,PUNTARENAS,OSA,HLE. PALMAR SUR                                           
605038,PUNTARENAS,OSA,LOS PLANES                                                
605039,PUNTARENAS,OSA,ALTO LAGUNA                                               
606001,PUNTARENAS,QUEPOS,QUEPOS                                                 
606002,PUNTARENAS,QUEPOS,CERRITOS                                               
606003,PUNTARENAS,QUEPOS,NARANJITO                                              
606004,PUNTARENAS,QUEPOS,PASITO                                                 
606006,PUNTARENAS,QUEPOS,DAMAS                                                  
606007,PUNTARENAS,QUEPOS,VILLANUEVA                                             
606009,PUNTARENAS,QUEPOS,MATAPALO                                               
606012,PUNTARENAS,QUEPOS,SAN RAFAEL (CERROS)                                    
606016,PUNTARENAS,QUEPOS,RONCADOR                                               
606017,PUNTARENAS,QUEPOS,HATILLO VIEJO (SANTA MARTA)                            
606020,PUNTARENAS,QUEPOS,PUNTO DE MIRA                                          
606021,PUNTARENAS,QUEPOS,MARITIMA                                               
606022,PUNTARENAS,QUEPOS,DOS BOCAS                                              
606023,PUNTARENAS,QUEPOS,TIERRAS MORENAS                                        
606025,PUNTARENAS,QUEPOS,PAQUITA                                                
606027,PUNTARENAS,QUEPOS,LONDRES                                                
606029,PUNTARENAS,QUEPOS,SILENCIO                                               
606031,PUNTARENAS,QUEPOS,LA INMACULADA                                          
606032,PUNTARENAS,QUEPOS,SANTO DOMINGO                                          
606033,PUNTARENAS,QUEPOS,MANUEL ANTONIO                                         
606034,PUNTARENAS,QUEPOS,BOCA VIEJA                                             
606035,PUNTARENAS,QUEPOS,COCAL                                                  
606036,PUNTARENAS,QUEPOS,SABALO                                                 
606037,PUNTARENAS,QUEPOS,PORTALON                                               
606038,PUNTARENAS,QUEPOS,HLE. QUEPOS                                            
607001,PUNTARENAS,GOLFITO,GOLFITO                                               
607005,PUNTARENAS,GOLFITO,VILLA BRICE�O (KM 37)                                 
607006,PUNTARENAS,GOLFITO,CONTE DE PAVON                                        
607007,PUNTARENAS,GOLFITO,FLORIDA (AGUADA)                                      
607008,PUNTARENAS,GOLFITO,ZANCUDO (PUERTO NUEVO)                                
607010,PUNTARENAS,GOLFITO,RIO CLARO                                             
607011,PUNTARENAS,GOLFITO,LA MONA                                               
607012,PUNTARENAS,GOLFITO,LA FORTUNA DE COTO                                    
607013,PUNTARENAS,GOLFITO,LA VIRGEN                                             
607014,PUNTARENAS,GOLFITO,PUNTA BANCO (NICARAGUA)                               
607015,PUNTARENAS,GOLFITO,LLANO BONITO                                          
607016,PUNTARENAS,GOLFITO,UNION DE COTO NORTE                                   
607017,PUNTARENAS,GOLFITO,VALLE DE LOS CEDROS O SAN MIGUEL                      
607019,PUNTARENAS,GOLFITO,KILOMETRO 16                                          
607020,PUNTARENAS,GOLFITO,BAHIA DE PAVON (COCAL AMARILLO)                       
607021,PUNTARENAS,GOLFITO,LA PE�A DE BURICA                                     
607023,PUNTARENAS,GOLFITO,CARACOL NORTE (PARTE)                                 
607024,PUNTARENAS,GOLFITO,GUAYMI DE BURICA                                      
607025,PUNTARENAS,GOLFITO,ALTO CONTE (MOLO DUBTDO)                              
607026,PUNTARENAS,GOLFITO,VIQUILLAS                                             
607027,PUNTARENAS,GOLFITO,PROGRESO DE CONTEBURICA                               
607028,PUNTARENAS,GOLFITO,CACAO                                                 
607029,PUNTARENAS,GOLFITO,RESIDENCIAL URE�A                                     
607030,PUNTARENAS,GOLFITO,ESCUADRA                                              
607031,PUNTARENAS,GOLFITO,LAGARTO (LA LUCHA)                                    
607032,PUNTARENAS,GOLFITO,KILOMETRO 20                                          
607033,PUNTARENAS,GOLFITO,GEMELAS (RIO CLARO DE PAVON)                          
607034,PUNTARENAS,GOLFITO,ESPERANZA                                             
607035,PUNTARENAS,GOLFITO,SAN RAMON                                             
607036,PUNTARENAS,GOLFITO,FINCA 54                                              
607037,PUNTARENAS,GOLFITO,HLE. GOLFITO                                          
607038,PUNTARENAS,GOLFITO,CUESTA CARONA                                         
607039,PUNTARENAS,GOLFITO,PUESTO LA PLAYA                                       
608001,PUNTARENAS,COTO BRUS,SAN VITO                                            
608002,PUNTARENAS,COTO BRUS,BAJO REYES                                          
608003,PUNTARENAS,COTO BRUS,LA ADMINISTRACION (GUTIERREZ BRAUN                  
608004,PUNTARENAS,COTO BRUS,SABALITO                                            
608005,PUNTARENAS,COTO BRUS,SAN MIGUEL DE LA FRONTERA                           
608006,PUNTARENAS,COTO BRUS,LAS MELLIZAS                                        
608007,PUNTARENAS,COTO BRUS,AGUABUENA                                           
608008,PUNTARENAS,COTO BRUS,LIMONCITO DEL OESTE                                 
608009,PUNTARENAS,COTO BRUS,LA UNION DE LIMONCITO                               
608010,PUNTARENAS,COTO BRUS,SAN RAFAEL DE LIMONCITO                             
608011,PUNTARENAS,COTO BRUS,SABANILLA                                           
608012,PUNTARENAS,COTO BRUS,CA�AS GORDAS                                        
608013,PUNTARENAS,COTO BRUS,COPAL                                               
608014,PUNTARENAS,COTO BRUS,SAN FRANCISCO DE AGUA BUENA                         
608015,PUNTARENAS,COTO BRUS,EL VALLE                                            
608016,PUNTARENAS,COTO BRUS,SAN GERARDO                                         
608018,PUNTARENAS,COTO BRUS,MONTERREY                                           
608019,PUNTARENAS,COTO BRUS,FILA MENDEZ                                         
608020,PUNTARENAS,COTO BRUS,SANTA ELENA                                         
608021,PUNTARENAS,COTO BRUS,FILA GUINEA                                         
608022,PUNTARENAS,COTO BRUS,FILA PINAR                                          
608023,PUNTARENAS,COTO BRUS,FLOR DEL ROBLE                                      
608024,PUNTARENAS,COTO BRUS,LOURDES                                             
608025,PUNTARENAS,COTO BRUS,LA LUCHA                                            
608026,PUNTARENAS,COTO BRUS,LOS ANGELES DE SABALITO                             
608027,PUNTARENAS,COTO BRUS,CONCEPCION                                          
608028,PUNTARENAS,COTO BRUS,SANTA CECILIA DE AGUA BUENA                         
608029,PUNTARENAS,COTO BRUS,CAMPO TRES                                          
608030,PUNTARENAS,COTO BRUS,SANTA RITA                                          
608031,PUNTARENAS,COTO BRUS,SANTA CLARA                                         
608032,PUNTARENAS,COTO BRUS,BRISAS                                              
608033,PUNTARENAS,COTO BRUS,PIEDRA PINTADA                                      
608034,PUNTARENAS,COTO BRUS,SAN ANTONIO                                         
608035,PUNTARENAS,COTO BRUS,LINDA VISTA (ALTO ZONCHO)                           
608036,PUNTARENAS,COTO BRUS,ROBLE                                               
608037,PUNTARENAS,COTO BRUS,AGUA CALIENTE                                       
608038,PUNTARENAS,COTO BRUS,AGUAS CLARAS                                        
608039,PUNTARENAS,COTO BRUS,SANTA TERESA                                        
608040,PUNTARENAS,COTO BRUS,CAMAQUIRI                                           
608041,PUNTARENAS,COTO BRUS,PALMIRA                                             
608042,PUNTARENAS,COTO BRUS,LA CASONA (GUAYMI)                                  
608043,PUNTARENAS,COTO BRUS,MARAVILLA                                           
608044,PUNTARENAS,COTO BRUS,BARRIO CANADA                                       
608045,PUNTARENAS,COTO BRUS,HLE. COTO BRUS                                      
608046,PUNTARENAS,COTO BRUS,SAN RAMON                                           
608047,PUNTARENAS,COTO BRUS,LA ISLA                                             
609001,PUNTARENAS,PARRITA,PUEBLO NUEVO                                          
609002,PUNTARENAS,PARRITA,ESTERILLOS OESTE                                      
609004,PUNTARENAS,PARRITA,CHIRES ARRIBA                                         
609005,PUNTARENAS,PARRITA,SARDINAL SUR                                          
609006,PUNTARENAS,PARRITA,PROYECTO LA LOMA ARRIBA                               
609007,PUNTARENAS,PARRITA,LOS ANGELES                                           
609008,PUNTARENAS,PARRITA,EL TIGRE                                              
609010,PUNTARENAS,PARRITA,CHIRRACA                                              
609011,PUNTARENAS,PARRITA,SAN ISIDRO DE PLAYON                                  
609012,PUNTARENAS,PARRITA,SURUBRES                                              
609013,PUNTARENAS,PARRITA,PALO SECO                                             
609014,PUNTARENAS,PARRITA,VUELTA DE POCARES                                     
609015,PUNTARENAS,PARRITA,POCARES                                               
609016,PUNTARENAS,PARRITA,LAS VEGAS (PORVENIR)                                  
609017,PUNTARENAS,PARRITA,SAN RAFAEL NORTE (RIO SECO)                           
609018,PUNTARENAS,PARRITA,LAS PARCELAS O DAMITAS (PIRRIS)                       
609019,PUNTARENAS,PARRITA,ISLA DAMAS                                            
609020,PUNTARENAS,PARRITA,PIRRIS                                                
609021,PUNTARENAS,PARRITA,BAMBU                                                 
609023,PUNTARENAS,PARRITA,VALLE VASCONIA (BARRO)                                
609024,PUNTARENAS,PARRITA,BEJUCO                                                
609025,PUNTARENAS,PARRITA,LA JULIETA                                            
609026,PUNTARENAS,PARRITA,PLAYON SUR                                            
609027,PUNTARENAS,PARRITA,BANDERA                                               
609028,PUNTARENAS,PARRITA,CARMEN (PARTE SUR)                                    
609029,PUNTARENAS,PARRITA,PLAYA ISLA PALO SECO                                  
609030,PUNTARENAS,PARRITA,HLE. PARRITA                                          
609031,PUNTARENAS,PARRITA,LOS SUE�OS                                            
610001,PUNTARENAS,CORREDORES,NEILY                                              
610002,PUNTARENAS,CORREDORES,CAMPO DOS Y MEDIO (PARTE SUR)                      
610003,PUNTARENAS,CORREDORES,BAJO LOS INDIOS                                    
610004,PUNTARENAS,CORREDORES,COTO CUARENTA Y DOS                                
610005,PUNTARENAS,CORREDORES,COTO CUARENTA Y SIETE                              
610006,PUNTARENAS,CORREDORES,ABROJO NORTE(VEGAS ABRO N)                         
610007,PUNTARENAS,CORREDORES,CAMPI�A                                            
610008,PUNTARENAS,CORREDORES,LA CUESTA                                          
610009,PUNTARENAS,CORREDORES,LAUREL                                             
610011,PUNTARENAS,CORREDORES,CANOAS                                             
610012,PUNTARENAS,CORREDORES,BARRIO NUEVO DE VERACRUZ (COL.SUR)                 
610013,PUNTARENAS,CORREDORES,COLORADO                                           
610014,PUNTARENAS,CORREDORES,MARIPOSA                                           
610015,PUNTARENAS,CORREDORES,LOS PLANES                                         
610016,PUNTARENAS,CORREDORES,CARMEN (COLORADITO NORTE)                          
610017,PUNTARENAS,CORREDORES,BELLA LUZ                                          
610018,PUNTARENAS,CORREDORES,COLONIA LIBERTAD (KM 31)                           
610019,PUNTARENAS,CORREDORES,LA NUBIA (KILOMETRO 25)                            
610020,PUNTARENAS,CORREDORES,CARACOL DE LA VACA                                 
610021,PUNTARENAS,CORREDORES,VEREH                                              
610022,PUNTARENAS,CORREDORES,RIO BONITO DE NEILY                                
610023,PUNTARENAS,CORREDORES,SAN MARTIN                                         
610024,PUNTARENAS,CORREDORES,FORTUNA                                            
610026,PUNTARENAS,CORREDORES,VEGAS DEL RIO LA VACA NIBIRIBOTDA                  
610027,PUNTARENAS,CORREDORES,ABROJO-MONTEZUMA                                   
610028,PUNTARENAS,CORREDORES,NARANJO                                            
610029,PUNTARENAS,CORREDORES,RIO NUEVO                                          
610030,PUNTARENAS,CORREDORES,HLE. NEILY                                         
610031,PUNTARENAS,CORREDORES,DARIZARA                                           
610032,PUNTARENAS,CORREDORES,BARRIO SAN JORGE                                   
610033,PUNTARENAS,CORREDORES,ALTOS DE SAN ANTONIO                               
611001,PUNTARENAS,GARABITO,JACO                                                 
611002,PUNTARENAS,GARABITO,TARCOLES                                             
611003,PUNTARENAS,GARABITO,QUEBRADA GANADO                                      
611005,PUNTARENAS,GARABITO,HERRADURA                                            
611006,PUNTARENAS,GARABITO,PUEBLO NUEVO (LA MONA)                               
611007,PUNTARENAS,GARABITO,LAGUNILLAS (PARTE OESTE)                             
611008,PUNTARENAS,GARABITO,POCHOTAL                                             
611009,PUNTARENAS,GARABITO,QUEBRADA AMARILLA                                    
612001,PUNTARENAS,MONTEVERDE,SANTA ELENA                                        
612002,PUNTARENAS,MONTEVERDE,CERRO PLANO                                        
612003,PUNTARENAS,MONTEVERDE,SAN LUIS DE MONTEVERDE                             
613001,PUNTARENAS,PUERTO JIMENEZ,PUERTO JIMENEZ                                 
613002,PUNTARENAS,PUERTO JIMENEZ, LA PALMA O INDEPENDENCIA                      
613003,PUNTARENAS,PUERTO JIMENEZ,CA�AZA DE JIMENEZ                              
613004,PUNTARENAS,PUERTO JIMENEZ,BOCA GALLARDO DE SANDALO                       
613005,PUNTARENAS,PUERTO JIMENEZ,CARBONERA                                      
701001,LIMON,CENTRAL,LIMON                                                      
701002,LIMON,CENTRAL,LIVERPOOL                                                  
701003,LIMON,CENTRAL,LA BOMBA                                                   
701004,LIMON,CENTRAL,LA COLONIA                                                 
701005,LIMON,CENTRAL,PENSHURT                                                   
701006,LIMON,CENTRAL,CRISTOBAL COLON                                            
701007,LIMON,CENTRAL,MOIN                                                       
701008,LIMON,CENTRAL,PUEBLO NUEVO O JAMAICA                                     
701009,LIMON,CENTRAL,VESTA                                                      
701010,LIMON,CENTRAL,SAN ANDRES                                                 
701011,LIMON,CENTRAL,RIO BLANCO                                                 
701012,LIMON,CENTRAL,WESTFALIA                                                  
701013,LIMON,CENTRAL,CORALES 2                                                  
701014,LIMON,CENTRAL,LIMONCITO O BARRIO QUINTO                                  
701015,LIMON,CENTRAL,SANTA ROSA                                                 
701017,LIMON,CENTRAL,BANANITO NORTE                                             
701018,LIMON,CENTRAL,BRISAS DE VERAGUA                                          
701019,LIMON,CENTRAL,SANTA EDUVIGIS                                             
701020,LIMON,CENTRAL,BUFALO                                                     
701021,LIMON,CENTRAL,BOCUARE                                                    
701022,LIMON,CENTRAL,VALLE DE LAS ROSAS                                         
701023,LIMON,CENTRAL,BEVERLEY                                                   
701024,LIMON,CENTRAL,AGUAS ZARCAS                                               
701025,LIMON,CENTRAL,PROGRESO                                                   
701026,LIMON,CENTRAL,SAN RAFAEL                                                 
701027,LIMON,CENTRAL,VILLA DEL MAR                                              
701028,LIMON,CENTRAL,LA COLINA                                                  
701029,LIMON,CENTRAL,SAN JUAN                                                   
701030,LIMON,CENTRAL,PANDORA ESTE (LA PLASTICA)                                 
701031,LIMON,CENTRAL,VALLE AURORA                                               
701032,LIMON,CENTRAL,GUARIA                                                     
701033,LIMON,CENTRAL,SANTA RITA                                                 
701034,LIMON,CENTRAL,ALTO CWEN                                                  
701035,LIMON,CENTRAL,XIQIARI                                                    
701036,LIMON,CENTRAL,SINOLI                                                     
701037,LIMON,CENTRAL,CAI. LIMON                                                 
701038,LIMON,CENTRAL,HLE. VICTOR CASCO TORRES                                   
701039,LIMON,CENTRAL,URBANIZACION PACUARE                                       
701040,LIMON,CENTRAL,CONCEPCION                                                 
701041,LIMON,CENTRAL,CANGREJOS                                                  
701042,LIMON,CENTRAL,ALMIRANTE                                                  
701043,LIMON,CENTRAL,GAVILAN (SHICALARBATA)                                     
701044,LIMON,CENTRAL,JAKKUE (SITIO HILDA PARTE ESTE)                            
701045,LIMON,CENTRAL,DONDONIA                                                   
701046,LIMON,CENTRAL,RIO BANANO                                                 
701047,LIMON,CENTRAL,LOMA LINDA                                                 
702001,LIMON,POCOCI,GUAPILES                                                    
702002,LIMON,POCOCI,BARRA DEL COLORADO                                          
702003,LIMON,POCOCI,JIMENEZ                                                     
702004,LIMON,POCOCI,LAS PALMITAS                                                
702005,LIMON,POCOCI,LA CURIA (BUENOS AIRES)                                     
702006,LIMON,POCOCI,CARIARI (CAMPO KENNEDY)                                     
702007,LIMON,POCOCI,ROXANA                                                      
702008,LIMON,POCOCI,LA MARAVILLA                                                
702009,LIMON,POCOCI,ANITA GRANDE                                                
702010,LIMON,POCOCI,RITA                                                        
702011,LIMON,POCOCI,CRUCE DE ROXANA (CRUCE DE ANABAN)                           
702012,LIMON,POCOCI,BANAMOLA                                                    
702013,LIMON,POCOCI,CRUCE DE JARDIN                                             
702014,LIMON,POCOCI,LAS MERCEDES (NAJERA)                                       
702015,LIMON,POCOCI,CAMPO CINCO (SEMILLERO)                                     
702016,LIMON,POCOCI,SAN RAFAEL                                                  
702017,LIMON,POCOCI,FLORES (UNION)                                              
702018,LIMON,POCOCI,TICABAN                                                     
702019,LIMON,POCOCI,DIAMANTES                                                   
702020,LIMON,POCOCI,SAN ANTONIO (EL HUMO)                                       
702021,LIMON,POCOCI,BOCA TORTUGUERO                                             
702022,LIMON,POCOCI,LA TERESA                                                   
702023,LIMON,POCOCI,PRIMAVERA                                                   
702024,LIMON,POCOCI,LOS ANGELES                                                 
702025,LIMON,POCOCI,CAMPO DOS                                                   
702026,LIMON,POCOCI,CUATRO ESQUINAS                                             
702027,LIMON,POCOCI,EL CEIBO                                                    
702028,LIMON,POCOCI,SANTA ROSA                                                  
702029,LIMON,POCOCI,LA MARINA                                                   
702030,LIMON,POCOCI,BELLA VISTA                                                 
702031,LIMON,POCOCI,PATIO SAN CRISTOBAL                                         
702032,LIMON,POCOCI,CEDRAL                                                      
702033,LIMON,POCOCI,SECTOR 8 (SAN GERARDO)                                      
702035,LIMON,POCOCI,CAI. CARLOS LUIS FALLAS (MOD. ABC)                          
702036,LIMON,POCOCI,CARLOTA                                                     
702037,LIMON,POCOCI,HLE. GUAPILES                                               
702038,LIMON,POCOCI,TORO AMARILLO                                               
702039,LIMON,POCOCI,SUERRE                                                      
702040,LIMON,POCOCI,LA FORTUNA                                                  
702041,LIMON,POCOCI,LLANO BONITO                                                
702042,LIMON,POCOCI,ASTUA PIRIE                                                 
702043,LIMON,POCOCI,PROGRESO                                                    
702044,LIMON,POCOCI,SAN FRANCISCO DE CA�O SECO                                  
702045,LIMON,POCOCI,LINDA VISTA                                                 
702046,LIMON,POCOCI,BUENOS AIRES                                                
702047,LIMON,POCOCI,SAN MARTIN                                                  
702048,LIMON,POCOCI,PORVENIR                                                    
702049,LIMON,POCOCI,CAI. CARLOS LUIS FALLAS (MOD. D-E)                          
702050,LIMON,POCOCI,CASCADAS 4                                                  
702051,LIMON,POCOCI,SAN BOSCO                                                   
702052,LIMON,POCOCI,HLE. CARIARI                                                
702053,LIMON,POCOCI,CAI. CARLOS LUIS F. (AGROPECUARIO)                          
702054,LIMON,POCOCI,UAI. 20 DE DICIEMBRE                                        
703001,LIMON,SIQUIRRES,SIQUIRRES                                                
703002,LIMON,SIQUIRRES,SANTO DOMINGO (PUEBLO CIVIL)                             
703003,LIMON,SIQUIRRES,SAN ALBERTO NUEVO                                        
703004,LIMON,SIQUIRRES,PACUARITO                                                
703005,LIMON,SIQUIRRES,ALEGRIA                                                  
703006,LIMON,SIQUIRRES,FLORIDA                                                  
703007,LIMON,SIQUIRRES,MILANO O NEGUEV                                          
703008,LIMON,SIQUIRRES,GERMANIA                                                 
703009,LIMON,SIQUIRRES,SAN ALEJO SANTA MARTA                                    
703010,LIMON,SIQUIRRES,EL CAIRO                                                 
703011,LIMON,SIQUIRRES,EL COCO                                                  
703012,LIMON,SIQUIRRES,CIMARRONES                                               
703013,LIMON,SIQUIRRES,SAN ISIDRO (ALTO HEREDIANA)                              
703014,LIMON,SIQUIRRES,FINCA IMPERIO 2                                          
703015,LIMON,SIQUIRRES,PERLA                                                    
703016,LIMON,SIQUIRRES,INDIANA TRES                                             
703017,LIMON,SIQUIRRES,MADRE DE DIOS                                            
703018,LIMON,SIQUIRRES,SAN ANTONIO                                              
703019,LIMON,SIQUIRRES,HEREDIANA                                                
703020,LIMON,SIQUIRRES,BOCA DE PARISMINA                                        
703021,LIMON,SIQUIRRES,SAN JOSE O BAJOS DE PASCUA(ESTAC)                        
703022,LIMON,SIQUIRRES,SAN ISIDRO O ALTOS DE PASCUA                             
703023,LIMON,SIQUIRRES,SEIS AMIGOS                                              
703024,LIMON,SIQUIRRES,SAN CARLOS                                               
703025,LIMON,SIQUIRRES,MARYLAND                                                 
703026,LIMON,SIQUIRRES,FREEMAN                                                  
703027,LIMON,SIQUIRRES,EL PEJE                                                  
703028,LIMON,SIQUIRRES,GUAYACAN                                                 
703029,LIMON,SIQUIRRES,LUCHA                                                    
703030,LIMON,SIQUIRRES,BANACOL (LA ESPERANZA)                                   
703031,LIMON,SIQUIRRES,CULTIVEZ                                                 
703032,LIMON,SIQUIRRES,BELLAVISTA                                               
703033,LIMON,SIQUIRRES,ALTO LAS BRISAS DE PACUARITO                             
703034,LIMON,SIQUIRRES,COCAL                                                    
703035,LIMON,SIQUIRRES,SAN MARTIN                                               
703036,LIMON,SIQUIRRES,PORTON IBERIA                                            
704001,LIMON,TALAMANCA,BRATSI (BAMBU O DON DIEGO)                               
704002,LIMON,TALAMANCA,AMUBRI                                                   
704003,LIMON,TALAMANCA,COROMA (COLOQCHA)                                        
704004,LIMON,TALAMANCA,SIXAOLA                                                  
704005,LIMON,TALAMANCA,CAHUITA                                                  
704006,LIMON,TALAMANCA,PUERTO VIEJO                                             
704007,LIMON,TALAMANCA,BRIBRI (FIELDS)                                          
704008,LIMON,TALAMANCA,SHIROLES (XIROLES)                                       
704009,LIMON,TALAMANCA,PARAISO                                                  
704010,LIMON,TALAMANCA,GANDOCA                                                  
704011,LIMON,TALAMANCA,MANZANILLO                                               
704012,LIMON,TALAMANCA,HONE CREEK                                               
704013,LIMON,TALAMANCA,KATSI                                                    
704014,LIMON,TALAMANCA,DAYTONIA                                                 
704015,LIMON,TALAMANCA,SEPEQUE                                                  
704016,LIMON,TALAMANCA,MARGARITA                                                
704017,LIMON,TALAMANCA,DINDIRI O CARBON DOS                                     
704018,LIMON,TALAMANCA,BORDON                                                   
704019,LIMON,TALAMANCA,SIBUJU                                                   
704020,LIMON,TALAMANCA,BAJO TELIRE (BAJO BLEY)                                  
704021,LIMON,TALAMANCA,HLE. SANTA LUISA                                         
704022,LIMON,TALAMANCA,YORKIN                                                   
704023,LIMON,TALAMANCA,ALTO TELIRE (BAJO PIEDRA MESA )                          
704024,LIMON,TALAMANCA,ALTO MARGARITA (KEKOLDI)                                 
705001,LIMON,MATINA,MATINA                                                      
705002,LIMON,MATINA,ZENT                                                        
705003,LIMON,MATINA,ESTRADA                                                     
705004,LIMON,MATINA,BATAN                                                       
705005,LIMON,MATINA,LUZON                                                       
705006,LIMON,MATINA,VEINTIOCHO MILLAS O WALDEK                                  
705007,LIMON,MATINA,CORINA                                                      
705008,LIMON,MATINA,BRISTOL                                                     
705009,LIMON,MATINA,CUBA CREEK (RIO CUBA)                                       
705010,LIMON,MATINA,SAHARA                                                      
705011,LIMON,MATINA,SANTA MARTA                                                 
705012,LIMON,MATINA,SANTA MARIA                                                 
705013,LIMON,MATINA,SAN MIGUEL                                                  
705014,LIMON,MATINA,LINEA B                                                     
705016,LIMON,MATINA,CUATRO MILLAS                                               
705017,LIMON,MATINA,PALMERA (CATSAQIBI)                                         
705018,LIMON,MATINA,ESPERANZA                                                   
705019,LIMON,MATINA,ESPAVEL (VEGAS)                                             
705020,LIMON,MATINA,BARBILLA NORTE                                              
705021,LIMON,MATINA,DAVAO                                                       
705022,LIMON,MATINA,DOS RAMAS                                                   
705023,LIMON,MATINA,GOSHEN (SAN JUAN)                                           
705024,LIMON,MATINA,RAMAL SIETE                                                 
705025,LIMON,MATINA,LARGA DISTANCIA                                             
705026,LIMON,MATINA,VENECIA                                                     
705027,LIMON,MATINA,PUNTA DE LANZA                                              
706001,LIMON,GUACIMO,GUACIMO                                                    
706002,LIMON,GUACIMO,HOGAR                                                      
706003,LIMON,GUACIMO,BOSQUE                                                     
706004,LIMON,GUACIMO,PARISMINA                                                  
706005,LIMON,GUACIMO,IROQUOIS                                                   
706006,LIMON,GUACIMO,POCORA PARTE NORTE                                         
706007,LIMON,GUACIMO,RIO JIMENEZ (BALSAVILLE)                                   
706008,LIMON,GUACIMO,SANTA ROSA                                                 
706009,LIMON,GUACIMO,VILLAFRANCA                                                
706010,LIMON,GUACIMO,OJO DE AGUA O SAN GDO (DESTIERRO)                          
706011,LIMON,GUACIMO,LOS ANGELES                                                
706012,LIMON,GUACIMO,SAN LUIS                                                   
706013,LIMON,GUACIMO,PUEBLO NUEVO O ZANCUDO                                     
706014,LIMON,GUACIMO,LIMBO                                                      
706015,LIMON,GUACIMO,POCORA PARTE SUR                                           
706016,LIMON,GUACIMO,ARGENTINA                                                  
706017,LIMON,GUACIMO,LAS COLINAS                                                
706018,LIMON,GUACIMO,HLE. DAVID GARRO                                           
706019,LIMON,GUACIMO,SAN GERARDO                                                
706020,LIMON,GUACIMO,LOMAS DE GUACIMO (LOMAS DE SIERPE)                         
801001,CONSULADO,ALEMANIA,BERLIN                                                
802001,CONSULADO,ARGENTINA,BUENOS AIRES                                         
803001,CONSULADO,AUSTRIA,VIENA                                                  
804001,CONSULADO,BELGICA,BRUSELAS                                               
806001,CONSULADO,BRASIL,BRASILIA                                                
807001,CONSULADO,CANADA,OTTAWA                                                  
808001,CONSULADO,CHILE,SANTIAGO                                                 
809001,CONSULADO,CHINA,BEIJING                                                  
809002,CONSULADO,CHINA,SHANGHAI                                                 
810001,CONSULADO,COLOMBIA,BOGOTA                                                
811001,CONSULADO,COREA,SEUL                                                     
812001,CONSULADO,CUBA,LA HABANA                                                 
813001,CONSULADO,ECUADOR,QUITO                                                  
814001,CONSULADO,ESTADOS UNIDOS,ATLANTA                                         
814002,CONSULADO,ESTADOS UNIDOS,HOUSTON                                         
814003,CONSULADO,ESTADOS UNIDOS,LOS ANGELES                                     
814004,CONSULADO,ESTADOS UNIDOS,MIAMI                                           
814005,CONSULADO,ESTADOS UNIDOS,NUEVA YORK                                      
814006,CONSULADO,ESTADOS UNIDOS,WASHINGTON D. C.                                
815001,CONSULADO,EL SALVADOR,SAN SALVADOR                                       
816001,CONSULADO,ESPA�A,MADRID                                                  
817001,CONSULADO,FRANCIA,PARIS                                                  
818001,CONSULADO,GUATEMALA,CIUDAD DE GUATEMALA                                  
819001,CONSULADO,HONDURAS,TEGUCIGALPA                                           
820001,CONSULADO,ISRAEL,TEL AVIV                                                
821001,CONSULADO,ITALIA,ROMA                                                    
822001,CONSULADO,JAPON,TOKIO                                                    
823001,CONSULADO,MEXICO,CIUDAD DE MEXICO                                        
824002,CONSULADO,NICARAGUA,MANAGUA                                              
826001,CONSULADO,PAISES BAJOS,LA HAYA                                           
827001,CONSULADO,PANAMA,CIUDAD DE PANAMA                                        
827002,CONSULADO,PANAMA,DAVID                                                   
828001,CONSULADO,PERU,LIMA                                                      
829001,CONSULADO,REINO UNIDO,LONDRES                                            
830001,CONSULADO,REPUBLICA DOMINICANA,SANTO DOMINGO                             
831001,CONSULADO,RUSIA,MOSCU                                                    
832001,CONSULADO,SINGAPUR,CIUDAD DE SINGAPUR                                    
833001,CONSULADO,SUIZA,BERNA                                                    
835001,CONSULADO,URUGUAY,MONTEVIDEO                                             
837001,CONSULADO,INDIA,NUEVA DELHI                                              
838001,CONSULADO,QATAR,DOHA                                                     
839001,CONSULADO,BOLIVIA,LA PAZ                                                 
840001,CONSULADO,PARAGUAY,ASUNCION                                              
841002,CONSULADO,AUSTRALIA,CANBERRA                                             
843001,CONSULADO,JAMAICA,KINGSTON                                               
844001,CONSULADO,TURQUIA,ANKARA                                                 
845001,CONSULADO,EMIRATOS ARABES UNIDOS,ABU DABI                                
846001,CONSULADO,INDONESIA,YAKARTA                                              
848001,CONSULADO,KENIA,NAIROBI                                                  
